"use client";

import React, { useEffect } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import {
  X,
  MessageCircle,
  ShieldAlert,
  ShieldCheck,
  Thermometer,
  Layers,
  Sparkles,
  FlaskConical,
  Truck,
  CheckCircle2,
} from "lucide-react";
import { Product } from "@/data/products";
import { generateWhatsAppLink } from "@/lib/whatsapp";

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
}

export default function ProductModal({ product, onClose }: ProductModalProps) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    if (product) {
      document.body.style.overflow = "hidden";
      window.addEventListener("keydown", handleKeyDown);
    }
    return () => {
      document.body.style.overflow = "unset";
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [product, onClose]);

  if (!product) return null;

  const whatsAppLink = generateWhatsAppLink({
    name: product.name,
    dosage: product.dosage,
    price: product.price,
    category: product.category,
  });

  const pixPrice = product.price > 0 ? Math.round(product.price * 0.9) : 0;
  const usdtPrice = product.price > 0 ? Math.round(product.price * 0.88) : 0;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 lg:p-8">
        
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-[#021035]/85 backdrop-blur-md transition-opacity"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="relative w-full max-w-3xl max-h-[92vh] overflow-y-auto bg-white rounded-3xl shadow-2xl border border-[#C59827]/40 z-10 flex flex-col"
        >
          {/* Header Bar */}
          <div className="sticky top-0 bg-white/95 backdrop-blur-md px-6 py-4 border-b border-slate-100 flex items-center justify-between z-20">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#C59827]" />
              <span className="text-xs font-semibold tracking-widest uppercase text-[#03184E]">
                FICHA TÉCNICA & COMERCIAL • EVORA
              </span>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-slate-100 text-slate-500 hover:text-[#03184E] transition-colors focus:outline-none"
              aria-label="Fechar modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Modal Body */}
          <div className="p-6 sm:p-8 space-y-8">
            {/* Top Overview: Image + Title + Category + Price */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-6 sm:gap-8 items-center">
              
              {/* Product Vial Showcase */}
              <div className="sm:col-span-5 relative aspect-square bg-[#F8F9FB] rounded-2xl p-6 border border-slate-200/80 flex items-center justify-center">
                <div className="relative w-full h-full">
                  <Image
                    src={product.image}
                    alt={`${product.name} ${product.dosage}`}
                    fill
                    className="object-contain"
                  />
                </div>
                <div className="absolute top-3 left-3 bg-[#03184E] text-[#DFC066] text-[10px] font-bold px-2.5 py-1 rounded-md tracking-wider uppercase">
                  {product.dosage}
                </div>
              </div>

              {/* Title & Core info */}
              <div className="sm:col-span-7 flex flex-col justify-center">
                <span className="text-xs font-semibold tracking-widest uppercase text-[#C59827]">
                  {product.category}
                </span>

                <h2 className="mt-1 text-2xl sm:text-3xl font-serif font-bold text-[#03184E] tracking-tight">
                  {product.name}
                </h2>

                <p className="mt-3 text-sm text-slate-600 leading-relaxed font-light">
                  {product.description}
                </p>

                {/* Pricing Box with Discounts */}
                <div className="mt-5 p-4 rounded-xl bg-[#F1F4F8] border border-slate-200 space-y-2">
                  <div className="flex items-baseline justify-between">
                    <span className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">
                      Valor de Catálogo
                    </span>
                    <span className="text-2xl font-serif font-bold text-[#03184E]">
                      {product.priceFormatted || (product.price > 0 ? `R$ ${product.price.toLocaleString("pt-BR")}` : "Sob consulta")}
                    </span>
                  </div>

                  {product.price > 0 && (
                    <div className="pt-2 border-t border-slate-200/80 flex flex-wrap gap-2 text-[11px]">
                      <span className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded font-medium">
                        PIX: <strong>R$ {pixPrice.toLocaleString("pt-BR")}</strong> (10% OFF)
                      </span>
                      <span className="bg-blue-50 text-blue-800 border border-blue-200 px-2 py-0.5 rounded font-medium">
                        USDT: <strong>R$ {usdtPrice.toLocaleString("pt-BR")}</strong> (12% OFF)
                      </span>
                      <span className="bg-slate-100 text-slate-700 border border-slate-200 px-2 py-0.5 rounded font-medium">
                        Cartão: até 3x s/ juros
                      </span>
                    </div>
                  )}
                </div>

                {/* Shipping & Insurance Guarantee */}
                <div className="mt-3 flex items-center gap-2 text-xs text-slate-500">
                  <Truck className="w-4 h-4 text-[#C59827]" />
                  <span>Frete não incluso • <strong>Produto segurado pela EVORA até a entrega</strong></span>
                </div>
              </div>
            </div>

            {/* Technical Specifications Matrix */}
            <div className="border-t border-slate-100 pt-6">
              <h3 className="text-xs font-semibold tracking-widest uppercase text-[#03184E] mb-4 flex items-center gap-2">
                <FlaskConical className="w-4 h-4 text-[#C59827]" />
                ESPECIFICAÇÕES TÉCNICAS E FARMACÊUTICAS
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-[#F8F9FB] border border-slate-200/70">
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#03184E] mb-1">
                    <ShieldCheck className="w-4 h-4 text-[#C59827]" />
                    <span>Grau de Pureza Analítica</span>
                  </div>
                  <p className="text-xs text-slate-600 font-medium">
                    {product.technicalInfo?.purity || "≥ 99% verificado via HPLC"}
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#F8F9FB] border border-slate-200/70">
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#03184E] mb-1">
                    <Thermometer className="w-4 h-4 text-[#C59827]" />
                    <span>Conservação e Estabilidade</span>
                  </div>
                  <p className="text-xs text-slate-600 font-medium">
                    {product.technicalInfo?.storage || "Refrigerado de 2°C a 8°C ao abrigo de luz"}
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#F8F9FB] border border-slate-200/70">
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#03184E] mb-1">
                    <Layers className="w-4 h-4 text-[#C59827]" />
                    <span>Apresentação Física</span>
                  </div>
                  <p className="text-xs text-slate-600 font-medium">
                    {product.presentation || "Frasco ampola estéril para reconstituição"}
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#F8F9FB] border border-slate-200/70">
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#03184E] mb-1">
                    <Sparkles className="w-4 h-4 text-[#C59827]" />
                    <span>Mecanismo & Classe</span>
                  </div>
                  <p className="text-xs text-slate-600 font-medium">
                    {product.technicalInfo?.class || "Peptídeo de alta especificidade"}
                  </p>
                </div>
              </div>
            </div>

            {/* Mandatory Regulatory Disclaimer */}
            <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200/80 flex items-start gap-3">
              <ShieldAlert className="w-5 h-5 text-amber-700 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-amber-900 leading-relaxed font-normal">
                <strong>Aviso Regulatório:</strong> Conteúdo exclusivamente informativo. As informações técnicas e comerciais devem ser validadas pela equipe responsável antes da publicação. A EVORA não fornece prescrições, condutas diagnósticas ou recomendações posológicas individualizadas.
              </p>
            </div>
          </div>

          {/* Modal Footer / Direct WhatsApp Purchase Conversion CTA */}
          <div className="sticky bottom-0 bg-white/95 backdrop-blur-md px-6 py-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3 z-20">
            <div className="text-xs text-slate-500 font-light text-center sm:text-left">
              Envio imediato com embalagem térmica e rastreio direto no WhatsApp.
            </div>

            <a
              href={whatsAppLink}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-full text-xs font-semibold tracking-wider uppercase bg-gradient-to-r from-[#C59827] via-[#DFC066] to-[#C59827] text-[#03184E] shadow-md hover:brightness-105 active:scale-95 transition-all"
            >
              <MessageCircle className="w-4 h-4 text-[#03184E]" />
              <span>Comprar este Composto no WhatsApp</span>
            </a>
          </div>

        </motion.div>
      </div>
    </AnimatePresence>
  );
}
