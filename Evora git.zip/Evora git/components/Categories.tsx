"use client";

import React from "react";
import { motion } from "framer-motion";
import {
  Flame,
  ShieldCheck,
  Sparkles,
  Brain,
  Activity,
  Gem,
  HeartPulse,
  ArrowRight,
} from "lucide-react";
import { CATEGORIES, ProductCategory, PRODUCTS } from "@/data/products";

interface CategoriesProps {
  onSelectCategory?: (category: ProductCategory) => void;
  selectedCategory?: string;
}

export default function Categories({
  onSelectCategory,
  selectedCategory,
}: CategoriesProps) {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "Flame":
        return Flame;
      case "ShieldCheck":
        return ShieldCheck;
      case "Sparkles":
        return Sparkles;
      case "Brain":
        return Brain;
      case "Activity":
        return Activity;
      case "Gem":
        return Gem;
      case "HeartPulse":
        return HeartPulse;
      default:
        return Sparkles;
    }
  };

  const handleCategoryClick = (category: ProductCategory) => {
    if (onSelectCategory) {
      onSelectCategory(category);
    }
    const catalogElement = document.getElementById("catalogo");
    if (catalogElement) {
      catalogElement.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="categorias" className="py-24 bg-[#F8F9FB] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-6 h-[1.5px] bg-[#C59827]" />
            <span className="text-xs font-semibold tracking-[0.2em] text-[#C59827] uppercase">
              PORTFÓLIO BIOMOLÉCULAS
            </span>
            <span className="w-6 h-[1.5px] bg-[#C59827]" />
          </div>

          <h2 className="text-3xl sm:text-5xl font-serif text-[#03184E] tracking-tight">
            Explore nossas categorias
          </h2>

          <p className="mt-4 text-base sm:text-lg text-slate-600 font-light leading-relaxed">
            Selecione uma área de atuação científica para filtrar instantaneamente as formulações disponíveis no catálogo EVORA.
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {CATEGORIES.map((cat, index) => {
            const Icon = getIcon(cat.icon);
            const count = PRODUCTS.filter((p) => p.category === cat.id).length;
            const isSelected = selectedCategory === cat.id;

            return (
              <motion.div
                key={cat.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.08 }}
                onClick={() => handleCategoryClick(cat.id)}
                className={`group cursor-pointer rounded-2xl p-6 sm:p-7 transition-all duration-300 relative flex flex-col justify-between border ${
                  isSelected
                    ? "bg-[#03184E] text-white border-[#C59827] shadow-xl shadow-[#03184E]/20"
                    : "bg-white text-[#0F141D] border-slate-200/80 hover:border-[#C59827]/70 hover:shadow-xl hover:shadow-[#03184E]/5 hover:-translate-y-1"
                }`}
              >
                <div>
                  {/* Top Bar with Icon & Counter */}
                  <div className="flex items-center justify-between mb-5">
                    <div
                      className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all duration-300 ${
                        isSelected
                          ? "bg-[#021035] text-[#DFC066] border border-[#C59827]/50"
                          : "bg-[#F1F4F8] text-[#03184E] group-hover:bg-[#03184E] group-hover:text-[#DFC066]"
                      }`}
                    >
                      <Icon className="w-6 h-6" />
                    </div>
                    <span
                      className={`text-[11px] font-semibold tracking-wider px-2.5 py-1 rounded-full border ${
                        isSelected
                          ? "bg-[#021035] text-[#DFC066] border-[#C59827]/40"
                          : "bg-slate-100 text-slate-500 border-slate-200 group-hover:border-[#C59827]/30"
                      }`}
                    >
                      {count} {count === 1 ? "composto" : "compostos"}
                    </span>
                  </div>

                  {/* Title */}
                  <h3
                    className={`text-lg font-serif font-semibold tracking-tight transition-colors duration-200 ${
                      isSelected
                        ? "text-white"
                        : "text-[#03184E] group-hover:text-[#03184E]"
                    }`}
                  >
                    {cat.label}
                  </h3>

                  {/* Description */}
                  <p
                    className={`mt-2.5 text-xs font-light leading-relaxed ${
                      isSelected
                        ? "text-slate-300"
                        : "text-slate-500 group-hover:text-slate-600"
                    }`}
                  >
                    {cat.description}
                  </p>
                </div>

                {/* Bottom link indicator */}
                <div className="mt-6 pt-4 border-t border-current/10 flex items-center justify-between text-xs font-medium tracking-wider uppercase">
                  <span
                    className={
                      isSelected
                        ? "text-[#DFC066]"
                        : "text-[#C59827] group-hover:text-[#03184E]"
                    }
                  >
                    Filtrar catálogo
                  </span>
                  <ArrowRight
                    className={`w-4 h-4 transition-transform duration-300 group-hover:translate-x-1 ${
                      isSelected ? "text-[#DFC066]" : "text-[#C59827]"
                    }`}
                  />
                </div>
              </motion.div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
