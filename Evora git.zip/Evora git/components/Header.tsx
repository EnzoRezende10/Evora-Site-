"use client";

import React, { useState, useEffect } from "react";
import Image from "next/image";
import { MessageCircle, Menu, X, ArrowRight } from "lucide-react";
import { generateWhatsAppLink } from "@/lib/whatsapp";

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { label: "Catálogo", href: "#catalogo" },
    { label: "Ciência", href: "#posicionamento" },
    { label: "Categorias", href: "#categorias" },
    { label: "Pagamento", href: "#condicoes" },
    { label: "Contato", href: "#contato" },
  ];

  const handleLinkClick = () => {
    setMobileMenuOpen(false);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? "bg-[#03184E]/95 backdrop-blur-md shadow-lg shadow-[#021035]/30 py-3 border-b border-[#C59827]/20"
          : "bg-gradient-to-b from-[#021035]/90 to-transparent py-5"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a
            href="#"
            className="flex items-center gap-3 group focus:outline-none"
            aria-label="EVORA Página Inicial"
          >
            <div className="relative w-36 sm:w-44 h-10 transition-transform duration-300 group-hover:scale-105">
              <Image
                src="/logo/evora-logo-white.svg"
                alt="EVORA Logo"
                fill
                priority
                className="object-contain object-left"
              />
            </div>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-sm font-medium tracking-wider text-slate-200 hover:text-[#DFC066] transition-colors duration-200 relative group py-1"
              >
                {link.label}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#C59827] transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </nav>

          {/* Right Action Button (Desktop) */}
          <div className="hidden md:flex items-center">
            <a
              href={generateWhatsAppLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2.5 px-5 py-2.5 rounded-full text-xs font-semibold tracking-wider uppercase bg-gradient-to-r from-[#C59827] to-[#DFB752] text-[#03184E] shadow-md hover:shadow-[#C59827]/30 hover:brightness-110 active:scale-95 transition-all duration-200"
            >
              <MessageCircle className="w-4 h-4 text-[#03184E]" />
              <span>Falar no WhatsApp</span>
            </a>
          </div>

          {/* Mobile Actions: WhatsApp Icon + Hamburger */}
          <div className="flex md:hidden items-center gap-2">
            <a
              href={generateWhatsAppLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-full bg-[#C59827] text-[#03184E] active:scale-95 transition-transform"
              aria-label="WhatsApp"
            >
              <MessageCircle className="w-4 h-4" />
            </a>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-200 hover:text-white focus:outline-none"
              aria-label={mobileMenuOpen ? "Fechar menu" : "Abrir menu"}
            >
              {mobileMenuOpen ? (
                <X className="w-6 h-6 text-[#DFC066]" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#03184E]/98 backdrop-blur-xl border-b border-[#C59827]/30 px-6 pt-4 pb-8 space-y-4 animate-in fade-in slide-in-from-top-4 duration-200 shadow-2xl">
          <div className="flex flex-col space-y-3 pt-2">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={handleLinkClick}
                className="text-base font-medium tracking-wide text-slate-100 hover:text-[#DFC066] py-2 border-b border-white/5 flex items-center justify-between"
              >
                <span>{link.label}</span>
                <ArrowRight className="w-4 h-4 text-[#C59827]/70" />
              </a>
            ))}
          </div>

          <div className="pt-4">
            <a
              href={generateWhatsAppLink()}
              target="_blank"
              rel="noopener noreferrer"
              onClick={handleLinkClick}
              className="w-full flex items-center justify-center gap-3 px-5 py-3.5 rounded-xl text-sm font-semibold tracking-wider uppercase bg-gradient-to-r from-[#C59827] to-[#DFB752] text-[#03184E] shadow-lg active:scale-98 transition-all"
            >
              <MessageCircle className="w-5 h-5 text-[#03184E]" />
              <span>Falar no WhatsApp</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
