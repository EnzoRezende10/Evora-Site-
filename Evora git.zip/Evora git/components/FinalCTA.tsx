"use client";

import React from "react";
import { motion } from "framer-motion";
import { MessageCircle, ArrowRight, ShieldCheck, Clock, Award } from "lucide-react";
import { generateWhatsAppLink } from "@/lib/whatsapp";

export default function FinalCTA() {
  return (
    <section id="contato" className="py-24 sm:py-32 bg-[#03184E] relative overflow-hidden">
      {/* Background Decorative Rings & Gradient */}
      <div className="absolute inset-0 bg-radial-gradient from-[#082A7C]/40 via-[#03184E] to-[#021035] pointer-events-none" />
      <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-[700px] h-[700px] rounded-full border border-[#C59827]/15 pointer-events-none" />
      <div className="absolute -top-16 left-1/2 -translate-x-1/2 w-[500px] h-[500px] rounded-full border border-[#C59827]/10 pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        
        {/* Subtle Brand Tag */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-[#C59827]/30 bg-[#021035]/60 backdrop-blur-md mb-8"
        >
          <span className="w-2 h-2 rounded-full bg-[#DFC066]" />
          <span className="text-[11px] font-semibold tracking-[0.25em] uppercase text-[#DFC066]">
            ATENDIMENTO EXCLUSIVO
          </span>
        </motion.div>

        {/* Main CTA Title */}
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-3xl sm:text-5xl lg:text-6xl font-serif text-white tracking-tight leading-tight max-w-4xl mx-auto"
        >
          Encontre a solução ideal <br />
          <span className="gold-gradient-text font-normal">para o seu objetivo.</span>
        </motion.h2>

        {/* Supporting text */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mt-6 text-base sm:text-xl text-slate-300 font-light max-w-2xl mx-auto leading-relaxed"
        >
          Converse com um consultor EVORA e conheça nosso catálogo. Esclareça dúvidas técnicas, consulte lotes e receba suporte dedicado.
        </motion.p>

        {/* Primary CTA Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <a
            href={generateWhatsAppLink(
              undefined,
              "Olá! Quero falar com um consultor da EVORA para conhecer o catálogo e condições especiais."
            )}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-10 py-5 rounded-full text-xs sm:text-sm font-semibold tracking-widest uppercase bg-gradient-to-r from-[#C59827] via-[#DFC066] to-[#C59827] text-[#03184E] shadow-2xl hover:shadow-[#C59827]/40 hover:brightness-105 active:scale-95 transition-all duration-300 group"
          >
            <MessageCircle className="w-5 h-5 text-[#03184E]" />
            <span>Falar com um consultor</span>
            <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
          </a>
        </motion.div>

        {/* Trust Badges */}
        <div className="mt-16 pt-10 border-t border-white/10 grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-3xl mx-auto text-left">
          <div className="flex items-center gap-3.5 text-slate-300">
            <ShieldCheck className="w-5 h-5 text-[#DFC066] flex-shrink-0" />
            <span className="text-xs font-light">Atendimento 100% confidencial e sigiloso</span>
          </div>

          <div className="flex items-center gap-3.5 text-slate-300">
            <Clock className="w-5 h-5 text-[#DFC066] flex-shrink-0" />
            <span className="text-xs font-light">Retorno rápido e suporte contínuo</span>
          </div>

          <div className="flex items-center gap-3.5 text-slate-300">
            <Award className="w-5 h-5 text-[#DFC066] flex-shrink-0" />
            <span className="text-xs font-light">Garantia de pureza molecular HPLC</span>
          </div>
        </div>

      </div>
    </section>
  );
}
