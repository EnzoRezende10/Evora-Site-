"use client";

import React from "react";
import Image from "next/image";
import { MessageCircle, Info, ShieldCheck, Check } from "lucide-react";
import { Product } from "@/data/products";
import { generateWhatsAppLink } from "@/lib/whatsapp";

interface ProductCardProps {
  product: Product;
  onOpenModal: (product: Product) => void;
}

export default function ProductCard({ product, onOpenModal }: ProductCardProps) {
  const whatsAppOrderLink = generateWhatsAppLink({
    name: product.name,
    dosage: product.dosage,
    price: product.price,
    category: product.category,
  });

  return (
    <div className="group relative bg-white rounded-2xl overflow-hidden border border-slate-200/80 hover:border-[#C59827]/70 shadow-sm hover:shadow-xl hover:shadow-[#03184E]/10 transition-all duration-300 flex flex-col justify-between hover:-translate-y-1">
      
      {/* Top Image Showcase */}
      <div className="relative aspect-[4/3] bg-gradient-to-b from-[#F8F9FB] to-[#F1F4F8] p-6 flex items-center justify-center overflow-hidden">
        {/* Subtle decorative background circle */}
        <div className="absolute w-44 h-44 rounded-full border border-[#C59827]/15 group-hover:scale-110 transition-transform duration-500 pointer-events-none" />

        <div className="relative w-full h-full max-h-48 transition-transform duration-500 group-hover:scale-105">
          <Image
            src={product.image}
            alt={`${product.name} ${product.dosage}`}
            fill
            className="object-contain"
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          />
        </div>

        {/* Featured Ribbon / Badge */}
        {product.featured && (
          <div className="absolute top-3.5 left-3.5 bg-gradient-to-r from-[#03184E] to-[#0A266E] text-[#DFC066] text-[10px] font-semibold tracking-widest uppercase px-3 py-1 rounded-full border border-[#C59827]/40 shadow-sm">
            DESTAQUE
          </div>
        )}

        {/* Dosage Badge */}
        <div className="absolute top-3.5 right-3.5 bg-white/95 backdrop-blur-sm text-[#03184E] text-[11px] font-bold tracking-wide px-2.5 py-1 rounded-lg border border-slate-200 shadow-sm">
          {product.dosage}
        </div>
      </div>

      {/* Card Content */}
      <div className="p-6 flex flex-col flex-grow justify-between">
        <div>
          {/* Category Tag */}
          <p className="text-[11px] font-semibold tracking-wider uppercase text-[#C59827] mb-1.5">
            {product.category}
          </p>

          {/* Product Name */}
          <h3 className="text-xl font-serif font-bold text-[#03184E] tracking-tight group-hover:text-[#021035] transition-colors">
            {product.name}
          </h3>

          {/* Short scientific description */}
          <p className="mt-2 text-xs text-slate-600 line-clamp-2 leading-relaxed font-light">
            {product.description}
          </p>

          {/* Quality assurance pill */}
          <div className="mt-4 flex items-center gap-2 text-[11px] text-slate-600 bg-[#F8F9FB] px-2.5 py-1.5 rounded-lg border border-slate-200/70 w-fit">
            <ShieldCheck className="w-3.5 h-3.5 text-[#C59827]" />
            <span>Pureza {product.technicalInfo?.purity || "≥ 99% HPLC"}</span>
          </div>
        </div>

        {/* Price & Commercial Status */}
        <div className="mt-6 pt-4 border-t border-slate-100">
          <div className="flex items-baseline justify-between mb-4">
            <div>
              <span className="text-[10px] tracking-wider uppercase text-slate-400 font-semibold block">
                VALOR DE CATÁLOGO
              </span>
              <span className="text-xl font-serif font-bold text-[#03184E]">
                {product.priceFormatted || (product.price > 0 ? `R$ ${product.price.toLocaleString("pt-BR")}` : "Sob consulta")}
              </span>
            </div>

            <div className="text-right">
              <span className="text-[10px] text-emerald-800 bg-emerald-100/90 font-semibold px-2 py-0.5 rounded-md inline-flex items-center gap-1">
                <Check className="w-2.5 h-2.5" /> Pronta Entrega
              </span>
              <span className="block text-[10px] text-slate-400 mt-0.5">Pix: 10% OFF</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-2.5">
            <button
              onClick={() => onOpenModal(product)}
              className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl text-xs font-semibold tracking-wider uppercase text-[#03184E] bg-[#F1F4F8] hover:bg-[#E5EBF2] border border-slate-200 transition-colors duration-200 active:scale-95"
            >
              <Info className="w-3.5 h-3.5 text-[#C59827]" />
              <span>Ficha Técnica</span>
            </button>

            <a
              href={whatsAppOrderLink}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl text-xs font-semibold tracking-wider uppercase text-[#03184E] bg-gradient-to-r from-[#C59827] to-[#DFB752] hover:brightness-105 shadow-sm active:scale-95 transition-all duration-200"
            >
              <MessageCircle className="w-3.5 h-3.5 text-[#03184E]" />
              <span>Comprar</span>
            </a>
          </div>
        </div>

      </div>
    </div>
  );
}
