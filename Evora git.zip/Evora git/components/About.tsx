"use client";

import React from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import { Award, Dna, CheckCircle2, ShieldCheck } from "lucide-react";

export default function About() {
  const pillars = [
    {
      icon: Award,
      title: "Pureza Molecular HPLC ≥ 99%",
      desc: "Rigoroso controle analítico e laudos laboratoriais por cromatografia líquida de alta performance.",
    },
    {
      icon: ShieldCheck,
      title: "Rastreabilidade & Cadeia Fria",
      desc: "Estabilidade farmacêutica preservada desde a liofilização até a entrega refrigerada final.",
    },
    {
      icon: Dna,
      title: "Sintetização de Alta Fidelidade",
      desc: "Peptídeos biomiméticos formulados para máxima bio-afinidade receptora e biodisponibilidade celular.",
    },
    {
      icon: CheckCircle2,
      title: "Consultoria Dedicada",
      desc: "Atendimento exclusivo com consultor especializado em protocolos de vitalidade e performance.",
    },
  ];

  return (
    <section id="posicionamento" className="py-24 sm:py-32 bg-[#F1F4F8] relative overflow-hidden">
      {/* Subtle decorative background glow */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#C59827]/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-[#03184E]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Sophisticated Scientific Visual */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-6 relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-[#C59827]/25 aspect-[4/3] sm:aspect-[16/12]">
              <Image
                src="/hero/lab-precision.svg"
                alt="Laboratório EVORA de Alta Precisão"
                fill
                className="object-cover object-center"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#021035]/80 via-transparent to-transparent" />
              <div className="absolute bottom-6 left-6 right-6">
                <span className="inline-block px-3 py-1 rounded-full text-[10px] font-semibold tracking-widest uppercase bg-[#C59827] text-[#03184E] mb-2">
                  PADRÃO BIOMÉDICO
                </span>
                <p className="text-white text-sm sm:text-base font-serif italic">
                  &ldquo;A ciência mais avançada ganha forma quando a precisão encontra o propósito da vida extraordinária.&rdquo;
                </p>
              </div>
            </div>

            {/* Subtle decorative floating badge */}
            <div className="absolute -bottom-6 -right-4 sm:-right-6 bg-white p-4 sm:p-5 rounded-2xl shadow-xl border border-slate-200 hidden sm:flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-[#03184E] flex items-center justify-center">
                <span className="text-[#DFC066] font-serif font-bold text-xl">E</span>
              </div>
              <div>
                <p className="text-xs font-semibold text-[#03184E] tracking-wider uppercase">EVORA Quality Seal</p>
                <p className="text-xs text-slate-500 font-light">Ultra-high purity certification</p>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Institutional Text & Concise Indicators */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-6 flex flex-col justify-center"
          >
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-[1.5px] bg-[#C59827]" />
              <span className="text-xs font-semibold tracking-[0.2em] text-[#C59827] uppercase">
                POSICIONAMENTO EVORA
              </span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-[#03184E] tracking-tight leading-tight">
              Precisão científica. <br />
              <span className="gold-gradient-text font-normal">Experiência extraordinária.</span>
            </h2>

            <p className="mt-6 text-base sm:text-lg text-slate-700 font-light leading-relaxed">
              A <strong>EVORA</strong> nasceu para redefinir as fronteiras da saúde celular e da longevidade ativa. Combinamos sintetização de ponta, biomimética molecular e rigor analítico para entregar peptídeos de pureza absoluta para quem não aceita nada menos que a excelência.
            </p>

            {/* Micro indicators grid */}
            <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-5 pt-4 border-t border-slate-200">
              {pillars.map((item, index) => {
                const Icon = item.icon;
                return (
                  <div key={index} className="flex items-start gap-3.5">
                    <div className="w-8 h-8 rounded-lg bg-[#03184E]/5 border border-[#C59827]/30 flex-shrink-0 flex items-center justify-center text-[#C59827]">
                      <Icon className="w-4 h-4 text-[#C59827]" />
                    </div>
                    <div>
                      <h4 className="text-sm font-semibold text-[#03184E]">
                        {item.title}
                      </h4>
                      <p className="mt-1 text-xs text-slate-600 font-light leading-relaxed">
                        {item.desc}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
