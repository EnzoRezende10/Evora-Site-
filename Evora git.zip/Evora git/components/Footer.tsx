"use client";

import React from "react";
import Image from "next/image";
import { MessageCircle, ArrowUp } from "lucide-react";
import { generateWhatsAppLink } from "@/lib/whatsapp";

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const navLinks = [
    { label: "Catálogo", href: "#catalogo" },
    { label: "Ciência", href: "#posicionamento" },
    { label: "Categorias", href: "#categorias" },
    { label: "Condições", href: "#condicoes" },
    { label: "Contato", href: "#contato" },
  ];

  return (
    <footer className="bg-[#020E2C] text-slate-400 text-xs border-t border-[#C59827]/20 pb-24 md:pb-12 pt-16 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Row */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-white/5 items-start">
          
          {/* Brand Column */}
          <div className="md:col-span-5 space-y-4">
            <div className="relative w-44 h-10">
              <Image
                src="/logo/evora-logo-white.svg"
                alt="EVORA Logo"
                fill
                className="object-contain object-left"
              />
            </div>
            
            <p className="text-slate-400 font-light text-sm max-w-sm leading-relaxed">
              Padrão internacional de qualidade em peptídeos biomiméticos, moduladores metabólicos e biofármacos para longevidade e alta performance.
            </p>

            <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest text-[#DFC066] uppercase">
              <span>Ciência</span>
              <span>•</span>
              <span>Precisão</span>
              <span>•</span>
              <span>Sofisticação</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-3">
            <h4 className="text-xs font-semibold tracking-widest uppercase text-white mb-4">
              Navegação
            </h4>
            <ul className="space-y-2.5">
              {navLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="hover:text-[#DFC066] transition-colors duration-200 block"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact & WhatsApp */}
          <div className="md:col-span-4 space-y-4">
            <h4 className="text-xs font-semibold tracking-widest uppercase text-white mb-4">
              Atendimento Dedicado
            </h4>
            <p className="text-slate-400 text-xs font-light leading-relaxed">
              Consultores disponíveis para esclarecer dúvidas de protocolo, especificações de pureza e logística em cadeia fria.
            </p>

            <div>
              <a
                href={generateWhatsAppLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2.5 px-5 py-2.5 rounded-full text-xs font-semibold tracking-wider uppercase bg-[#C59827] text-[#03184E] hover:brightness-110 transition-all"
              >
                <MessageCircle className="w-4 h-4 text-[#03184E]" />
                <span>WhatsApp Oficial</span>
              </a>
            </div>
          </div>

        </div>

        {/* Regulatory & Legal Disclaimers */}
        <div className="py-8 border-b border-white/5 space-y-3 text-[11px] text-slate-500 font-light leading-relaxed">
          <p>
            <strong>Aviso Legal & Regulatório:</strong> Conteúdo exclusivamente informativo e voltado à elucidação técnica e científica. As informações técnicas e comerciais devem ser validadas pela equipe responsável antes da publicação. A EVORA não prescreve terapias, não substitui consultas com profissionais de saúde habilitados e preza estritamente pela conformidade legal e ética.
          </p>
          <p>
            Os compostos e reagentes fornecidos destinam-se a fins biomédicos e protocolos amparados pelas legislações pertinentes. Mantenha os produtos armazenados estritamente sob as faixas térmicas indicadas nos laudos analíticos.
          </p>
        </div>

        {/* Bottom Copyright & Back to Top */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500 text-[11px]">
          <p>
            © 2026 EVORA. Todos os direitos reservados.
          </p>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 hover:text-[#DFC066] transition-colors"
          >
            <span>Voltar ao topo</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </footer>
  );
}
