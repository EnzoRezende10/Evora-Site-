"use client";

import React from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import { ArrowDown, MessageSquare, Dna, BarChart3, Flower2, Hexagon } from "lucide-react";
import { generateWhatsAppLink } from "@/lib/whatsapp";

export default function Hero() {
  const indicators = [
    { label: "Saúde Integrada", icon: Dna, desc: "Equilíbrio sistêmico & biomimetismo" },
    { label: "Alta Performance", icon: BarChart3, desc: "Otimização bioenergética & foco" },
    { label: "Longevidade Real", icon: Flower2, desc: "Preservação celular & mitocondrial" },
    { label: "Beleza Funcional", icon: Hexagon, desc: "Bioestimulação dérmica & colágeno" },
  ];

  return (
    <section className="relative min-h-screen flex items-center justify-center pt-28 pb-20 overflow-hidden bg-[#021035]">
      {/* Background Graphic & Texture */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/hero/hero-bg.svg"
          alt="EVORA Biotechnology Background"
          fill
          priority
          className="object-cover object-center opacity-85"
        />
        {/* Soft Vignette Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#021035] via-transparent to-[#021035]/60" />
        <div className="absolute inset-0 bg-[#03184E]/40 backdrop-brightness-95" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full text-center">
        {/* Small Prestige Eyebrow matching Catalog */}
        <motion.div
          initial={{ opacity: 0, y: -15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-[#C59827]/40 bg-[#03184E]/60 backdrop-blur-md mb-6"
        >
          <span className="w-2 h-2 rounded-full bg-[#C59827] animate-pulse" />
          <span className="text-[10px] sm:text-xs font-semibold tracking-[0.25em] uppercase text-[#DFC066]">
            CIÊNCIA • SAÚDE • LONGEVIDADE • RESULTADOS
          </span>
        </motion.div>

        {/* Hero Title */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.15 }}
          className="text-4xl sm:text-6xl lg:text-7xl font-serif text-white tracking-tight leading-[1.15] max-w-5xl mx-auto"
        >
          Mais que peptídeos, <br className="hidden sm:inline" />
          <span className="gold-gradient-text font-normal">um novo padrão de vida.</span>
        </motion.h1>

        {/* Hero Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="mt-6 text-base sm:text-xl text-slate-300 max-w-3xl mx-auto font-light leading-relaxed tracking-wide"
        >
          Ciência, inovação e sofisticação para uma nova perspectiva de performance,
          longevidade e bem-estar.
        </motion.p>

        {/* Brand Tagline */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="mt-3 text-xs tracking-[0.3em] uppercase text-[#C59827] font-semibold"
        >
          SCIENCE FOR A BETTER YOU
        </motion.p>

        {/* Conversion Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.45 }}
          className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6"
        >
          <a
            href="#catalogo"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full text-xs sm:text-sm font-semibold tracking-widest uppercase bg-gradient-to-r from-[#C59827] via-[#DFC066] to-[#C59827] text-[#03184E] shadow-xl hover:shadow-[#C59827]/25 hover:brightness-105 active:scale-95 transition-all duration-300"
          >
            <span>Explorar catálogo</span>
            <ArrowDown className="w-4 h-4 animate-bounce" />
          </a>

          <a
            href={generateWhatsAppLink()}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full text-xs sm:text-sm font-semibold tracking-widest uppercase bg-[#03184E]/70 hover:bg-[#03184E] text-white border border-[#C59827]/50 hover:border-[#DFC066] backdrop-blur-md shadow-lg active:scale-95 transition-all duration-300"
          >
            <MessageSquare className="w-4 h-4 text-[#DFC066]" />
            <span>Falar com consultor</span>
          </a>
        </motion.div>

        {/* Four Key Scientific Indicators from the Catalog */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-16 sm:mt-24 grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-6 max-w-6xl mx-auto"
        >
          {indicators.map((item, index) => {
            const Icon = item.icon;
            return (
              <div
                key={index}
                className="group relative p-4 sm:p-6 rounded-2xl bg-[#03184E]/45 border border-[#C59827]/20 hover:border-[#C59827]/60 backdrop-blur-md transition-all duration-300 text-left hover:-translate-y-1 shadow-lg"
              >
                <div className="w-10 h-10 rounded-xl bg-[#021035] border border-[#C59827]/30 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300">
                  <Icon className="w-5 h-5 text-[#DFC066]" />
                </div>
                <h3 className="text-sm sm:text-base font-semibold text-white tracking-wide font-serif">
                  {item.label}
                </h3>
                <p className="mt-1 text-[11px] sm:text-xs text-slate-400 font-light leading-snug">
                  {item.desc}
                </p>
              </div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
