"use client";

import React, { useState, useMemo } from "react";
import { Search, SlidersHorizontal, Sparkles, MessageSquare, X } from "lucide-react";
import { PRODUCTS, CATEGORIES, ProductCategory, Product } from "@/data/products";
import ProductCard from "./ProductCard";
import ProductModal from "./ProductModal";
import { generateWhatsAppLink } from "@/lib/whatsapp";

interface ProductCatalogProps {
  selectedCategory: string;
  onSelectCategory: (category: ProductCategory | "all") => void;
}

export default function ProductCatalog({
  selectedCategory,
  onSelectCategory,
}: ProductCatalogProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeModalProduct, setActiveModalProduct] = useState<Product | null>(null);

  // Filter products by selected category and search term
  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((product) => {
      const matchesCategory =
        selectedCategory === "all" || product.category === selectedCategory;

      const matchesSearch =
        searchQuery.trim() === "" ||
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.dosage.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase());

      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchQuery]);

  return (
    <section id="catalogo" className="py-24 sm:py-32 bg-[#F8F9FB] relative scroll-mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-6 h-[1.5px] bg-[#C59827]" />
            <span className="text-xs font-semibold tracking-[0.2em] text-[#C59827] uppercase">
              CATÁLOGO COMPLETO
            </span>
            <span className="w-6 h-[1.5px] bg-[#C59827]" />
          </div>

          <h2 className="text-3xl sm:text-5xl font-serif text-[#03184E] tracking-tight">
            Seleção EVORA
          </h2>

          <p className="mt-4 text-base sm:text-lg text-slate-600 font-light leading-relaxed">
            Consulte a nossa linha de peptídeos puros, fatores regenerativos e biomoléculas de alto padrão científico.
          </p>
        </div>

        {/* Filter & Search Bar */}
        <div className="mb-10 space-y-6">
          
          {/* Search Box */}
          <div className="max-w-xl mx-auto relative">
            <div className="relative flex items-center">
              <Search className="w-5 h-5 text-slate-400 absolute left-4 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar por composto, dosagem ou objetivo (ex: Retatrutida, BPC-157, Sono)..."
                className="w-full pl-12 pr-10 py-3.5 rounded-2xl bg-white border border-slate-200 text-sm text-[#0F141D] placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#C59827] focus:border-transparent shadow-sm transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-4 text-slate-400 hover:text-slate-600 focus:outline-none"
                  aria-label="Limpar busca"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none justify-start md:justify-center">
            <button
              onClick={() => onSelectCategory("all")}
              className={`px-4 py-2 rounded-full text-xs font-semibold tracking-wider uppercase whitespace-nowrap transition-all duration-200 border ${
                selectedCategory === "all"
                  ? "bg-[#03184E] text-[#DFC066] border-[#C59827] shadow-md"
                  : "bg-white text-slate-600 border-slate-200 hover:border-[#C59827]/50 hover:text-[#03184E]"
              }`}
            >
              Todos ({PRODUCTS.length})
            </button>

            {CATEGORIES.map((cat) => {
              const isSelected = selectedCategory === cat.id;
              const count = PRODUCTS.filter((p) => p.category === cat.id).length;

              return (
                <button
                  key={cat.id}
                  onClick={() => onSelectCategory(cat.id)}
                  className={`px-4 py-2 rounded-full text-xs font-semibold tracking-wider uppercase whitespace-nowrap transition-all duration-200 border ${
                    isSelected
                      ? "bg-[#03184E] text-[#DFC066] border-[#C59827] shadow-md"
                      : "bg-white text-slate-600 border-slate-200 hover:border-[#C59827]/50 hover:text-[#03184E]"
                  }`}
                >
                  {cat.label} ({count})
                </button>
              );
            })}
          </div>

          {/* Results Summary Bar */}
          <div className="flex items-center justify-between text-xs text-slate-500 px-2 pt-2 border-t border-slate-200/60">
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="w-3.5 h-3.5 text-[#C59827]" />
              <span>
                Exibindo <strong>{filteredProducts.length}</strong> de{" "}
                <strong>{PRODUCTS.length}</strong> produtos
              </span>
            </div>

            {selectedCategory !== "all" && (
              <button
                onClick={() => onSelectCategory("all")}
                className="text-xs text-[#C59827] hover:underline font-medium"
              >
                Limpar filtro de categoria
              </button>
            )}
          </div>
        </div>

        {/* Products Grid */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 sm:gap-8">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onOpenModal={setActiveModalProduct}
              />
            ))}
          </div>
        ) : (
          /* Empty State */
          <div className="bg-white rounded-3xl p-12 text-center max-w-xl mx-auto border border-slate-200 shadow-sm">
            <div className="w-16 h-16 rounded-2xl bg-[#F1F4F8] text-[#C59827] flex items-center justify-center mx-auto mb-4">
              <Sparkles className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-serif font-bold text-[#03184E]">
              Nenhum composto encontrado
            </h3>
            <p className="mt-2 text-sm text-slate-500 font-light leading-relaxed">
              Não encontramos nenhum produto correspondente aos filtros aplicados.
              Experimente buscar por outro termo ou fale diretamente com a equipe.
            </p>
            <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={() => {
                  setSearchQuery("");
                  onSelectCategory("all");
                }}
                className="px-5 py-2.5 rounded-full text-xs font-semibold tracking-wider uppercase bg-[#F1F4F8] hover:bg-slate-200 text-[#03184E] transition-colors"
              >
                Restaurar todos os produtos
              </button>
              <a
                href={generateWhatsAppLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-2.5 rounded-full text-xs font-semibold tracking-wider uppercase bg-[#C59827] text-[#03184E] hover:brightness-105 transition-all flex items-center gap-2"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Consultar por WhatsApp</span>
              </a>
            </div>
          </div>
        )}

        {/* Bottom Catalog Action */}
        <div className="mt-16 text-center">
          <p className="text-sm text-slate-500 font-light mb-4">
            Procurando uma dosagem personalizada ou outro peptídeo sob encomenda?
          </p>
          <a
            href={generateWhatsAppLink(
              undefined,
              "Olá! Gostaria de consultar a disponibilidade de um peptídeo/dosagem sob encomenda não listado no catálogo."
            )}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full text-xs font-semibold tracking-widest uppercase bg-[#03184E] hover:bg-[#0A266E] text-[#DFC066] border border-[#C59827]/40 shadow-md hover:shadow-lg transition-all"
          >
            <MessageSquare className="w-4 h-4 text-[#DFC066]" />
            <span>Consultar formulações especiais</span>
          </a>
        </div>

      </div>

      {/* Product Detail Modal */}
      <ProductModal
        product={activeModalProduct}
        onClose={() => setActiveModalProduct(null)}
      />
    </section>
  );
}
