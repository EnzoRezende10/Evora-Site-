"use client";

import React from "react";
import { motion } from "framer-motion";
import { QrCode, CreditCard, Coins, Check, ShieldCheck, Truck, Shield } from "lucide-react";

export default function CommercialConditions() {
  const conditions = [
    {
      title: "PIX",
      discount: "10% OFF",
      desc: "Liquidação imediata com 10% de desconto em todo o catálogo e prioridade máxima de expedição.",
      icon: QrCode,
      features: [
        "10% de desconto instantâneo",
        "Confirmação e separação em até 1h",
        "Disponível 24 horas por dia",
      ],
      highlight: false,
    },
    {
      title: "CARTÃO DE CRÉDITO",
      discount: "Até 3x sem juros",
      desc: "Conveniência e flexibilidade no parcelamento em até 3 vezes sem acréscimo com total discrição.",
      icon: CreditCard,
      features: [
        "Parcelamento em até 3x s/ juros",
        "Ambiente de checkout criptografado",
        "Principais bandeiras aceitas",
      ],
      highlight: true,
    },
    {
      title: "USDT / CRIPTO",
      discount: "12% OFF",
      desc: "A maior vantagem comercial com 12% de desconto total para pagamentos via stablecoins.",
      icon: Coins,
      features: [
        "12% de desconto no pedido",
        "Redes TRC20, ERC20 e Polygon",
        "Máxima privacidade e rapidez",
      ],
      highlight: false,
    },
  ];

  return (
    <section id="condicoes" className="py-24 sm:py-32 bg-[#021035] relative overflow-hidden text-white">
      {/* Decorative background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#0A266E]/30 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-6 h-[1.5px] bg-[#C59827]" />
            <span className="text-xs font-semibold tracking-[0.2em] text-[#DFC066] uppercase">
              CONDIÇÕES COMERCIAIS EVORA
            </span>
            <span className="w-6 h-[1.5px] bg-[#C59827]" />
          </div>

          <h2 className="text-3xl sm:text-5xl font-serif tracking-tight text-white">
            Condições especiais de pagamento
          </h2>

          <p className="mt-4 text-base sm:text-lg text-slate-300 font-light leading-relaxed">
            Formas de pagamento facilitadas, com descontos exclusivos e garantia integral de entrega.
          </p>
        </div>

        {/* 3 Premium Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {conditions.map((item, index) => {
            const Icon = item.icon;

            return (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.15 }}
                className={`relative rounded-3xl p-8 transition-all duration-300 flex flex-col justify-between ${
                  item.highlight
                    ? "bg-gradient-to-b from-[#062164] to-[#03184E] border-2 border-[#C59827] shadow-2xl shadow-[#C59827]/15 sm:-translate-y-2"
                    : "bg-[#03184E]/70 border border-[#C59827]/30 hover:border-[#C59827]/60 shadow-xl backdrop-blur-md"
                }`}
              >
                {/* Popular Badge */}
                {item.highlight && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-gradient-to-r from-[#C59827] to-[#DFB752] text-[#03184E] text-[10px] font-bold tracking-widest uppercase px-4 py-1 rounded-full shadow-md">
                    MAIS CONVENIENTE
                  </div>
                )}

                <div>
                  {/* Top Bar with Icon & Title */}
                  <div className="flex items-center justify-between mb-6">
                    <div className="w-12 h-12 rounded-2xl bg-[#021035] border border-[#C59827]/40 flex items-center justify-center text-[#DFC066]">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-xs font-semibold tracking-wider text-slate-400 uppercase">
                      {item.title}
                    </span>
                  </div>

                  {/* Discount / Condition Highlight */}
                  <div className="mb-4">
                    <span className="text-3xl sm:text-4xl font-serif font-bold text-white tracking-tight">
                      {item.discount}
                    </span>
                  </div>

                  {/* Description */}
                  <p className="text-xs sm:text-sm text-slate-300 font-light leading-relaxed mb-6">
                    {item.desc}
                  </p>

                  {/* Bullet Points */}
                  <div className="space-y-3 pt-4 border-t border-white/10">
                    {item.features.map((feat, fIdx) => (
                      <div key={fIdx} className="flex items-center gap-2.5 text-xs text-slate-200">
                        <div className="w-4 h-4 rounded-full bg-[#C59827]/20 flex items-center justify-center flex-shrink-0">
                          <Check className="w-2.5 h-2.5 text-[#DFC066]" />
                        </div>
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Bottom Trust Seal */}
                <div className="mt-8 pt-4 border-t border-white/5 flex items-center gap-2 text-[11px] text-slate-400">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#DFC066]" />
                  <span>Transação criptografada & confidencial</span>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Shipping & Insurance Banner directly from Catalog requirements */}
        <div className="mt-14 max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="rounded-2xl p-5 bg-[#03184E]/70 border border-[#C59827]/30 backdrop-blur-md flex items-center gap-4">
            <div className="w-11 h-11 rounded-xl bg-[#021035] border border-[#C59827]/40 text-[#DFC066] flex items-center justify-center flex-shrink-0">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-semibold text-white">Garantia Total de Entrega</p>
              <p className="text-xs text-slate-300 font-light">Produto segurado pela EVORA até a entrega final ao cliente.</p>
            </div>
          </div>

          <div className="rounded-2xl p-5 bg-[#03184E]/70 border border-[#C59827]/30 backdrop-blur-md flex items-center gap-4">
            <div className="w-11 h-11 rounded-xl bg-[#021035] border border-[#C59827]/40 text-[#DFC066] flex items-center justify-center flex-shrink-0">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-semibold text-white">Envio em Cadeia Fria</p>
              <p className="text-xs text-slate-300 font-light">Frete calculado à parte com isolamento térmico estrito de 2°C a 8°C.</p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
