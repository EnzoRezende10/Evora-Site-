"use client";

import React, { useState, useEffect } from "react";
import { MessageCircle } from "lucide-react";
import { generateWhatsAppLink } from "@/lib/whatsapp";

export default function WhatsAppButton() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Show floating button after scrolling 150px
      setIsVisible(window.scrollY > 150);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const whatsAppLink = generateWhatsAppLink();

  if (!isVisible) return null;

  return (
    <>
      {/* Desktop Floating Button (Bottom Right) */}
      <div className="hidden md:block fixed bottom-8 right-8 z-50">
        <a
          href={whatsAppLink}
          target="_blank"
          rel="noopener noreferrer"
          className="group relative flex items-center gap-3 p-4 rounded-full bg-gradient-to-r from-[#C59827] to-[#DFB752] text-[#03184E] shadow-2xl hover:shadow-[#C59827]/40 active:scale-95 transition-all duration-300 hover:scale-105"
          aria-label="Falar com consultor via WhatsApp"
        >
          {/* Subtle pulsating outer ring */}
          <span className="absolute inset-0 rounded-full bg-[#C59827] opacity-40 animate-ping pointer-events-none" />

          <MessageCircle className="w-6 h-6 text-[#03184E] relative z-10" />

          {/* Expandable Label */}
          <span className="max-w-0 overflow-hidden whitespace-nowrap text-xs font-bold tracking-wider uppercase transition-all duration-300 ease-in-out group-hover:max-w-xs group-hover:pr-2">
            Falar com Consultor
          </span>
        </a>
      </div>

      {/* Mobile Fixed Bottom Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 p-3 bg-[#03184E]/95 backdrop-blur-md border-t border-[#C59827]/30 shadow-2xl safe-area-bottom">
        <a
          href={whatsAppLink}
          target="_blank"
          rel="noopener noreferrer"
          className="w-full flex items-center justify-center gap-2.5 py-3.5 px-4 rounded-xl text-xs font-bold tracking-widest uppercase bg-gradient-to-r from-[#C59827] to-[#DFB752] text-[#03184E] shadow-lg active:scale-98 transition-all"
        >
          <MessageCircle className="w-4 h-4 text-[#03184E]" />
          <span>Falar com Consultor no WhatsApp</span>
        </a>
      </div>
    </>
  );
}
