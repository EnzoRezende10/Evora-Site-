const fs = require('fs');
const path = require('path');

const publicDir = 'C:/Users/enzo.augusto/.gemini/antigravity/scratch/evora/public';

// 1. Logo SVG
const logoSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 100" fill="none">
  <defs>
    <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#E5C368" />
      <stop offset="50%" stop-color="#C59827" />
      <stop offset="100%" stop-color="#9E7719" />
    </linearGradient>
    <linearGradient id="shieldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0B2363" />
      <stop offset="100%" stop-color="#03184E" />
    </linearGradient>
  </defs>
  <!-- Monogram Crest -->
  <g transform="translate(20, 15)">
    <circle cx="35" cy="35" r="32" stroke="url(#goldGrad)" stroke-width="1.5" fill="none" opacity="0.6"/>
    <polygon points="35,10 57,23 57,47 35,60 13,47 13,23" stroke="url(#goldGrad)" stroke-width="1.2" fill="url(#shieldGrad)"/>
    <path d="M28 26 H43 V30 H32 V33 H41 V37 H32 V41 H43 V45 H28 Z" fill="url(#goldGrad)"/>
    <!-- Small star accent -->
    <polygon points="35,5 36.5,8 40,8.5 37.5,11 38,14.5 35,13 32,14.5 32.5,11 30,8.5 33.5,8" fill="#C59827" opacity="0.8"/>
  </g>
  <!-- Wordmark -->
  <text x="105" y="47" font-family="'Tenor Sans', 'Cinzel', serif" font-size="34" letter-spacing="8" fill="#03184E" font-weight="600">EVORA</text>
  <text x="107" y="66" font-family="'Inter', sans-serif" font-size="8.5" letter-spacing="5" fill="#C59827" font-weight="500">PRECISÃO • CIÊNCIA • LONGEVIDADE</text>
</svg>`;

fs.writeFileSync(path.join(publicDir, 'logo', 'evora-logo.svg'), logoSvg);

// Dark version logo for header / hero / dark footer
const logoWhiteSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 100" fill="none">
  <defs>
    <linearGradient id="goldGradWhite" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#F2D888" />
      <stop offset="50%" stop-color="#C59827" />
      <stop offset="100%" stop-color="#9E7719" />
    </linearGradient>
  </defs>
  <g transform="translate(20, 15)">
    <circle cx="35" cy="35" r="32" stroke="url(#goldGradWhite)" stroke-width="1.5" fill="none" opacity="0.6"/>
    <polygon points="35,10 57,23 57,47 35,60 13,47 13,23" stroke="url(#goldGradWhite)" stroke-width="1.2" fill="#021035"/>
    <path d="M28 26 H43 V30 H32 V33 H41 V37 H32 V41 H43 V45 H28 Z" fill="url(#goldGradWhite)"/>
    <polygon points="35,5 36.5,8 40,8.5 37.5,11 38,14.5 35,13 32,14.5 32.5,11 30,8.5 33.5,8" fill="#E5C368" opacity="0.9"/>
  </g>
  <text x="105" y="47" font-family="'Tenor Sans', 'Cinzel', serif" font-size="34" letter-spacing="8" fill="#FFFFFF" font-weight="600">EVORA</text>
  <text x="107" y="66" font-family="'Inter', sans-serif" font-size="8.5" letter-spacing="5" fill="#C59827" font-weight="500">PRECISÃO • CIÊNCIA • LONGEVIDADE</text>
</svg>`;

fs.writeFileSync(path.join(publicDir, 'logo', 'evora-logo-white.svg'), logoWhiteSvg);

// 2. Hero Background SVG (Deep luxury biomedical background with dark navy, gold constellations, peptide helixes)
const heroBgSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 1080" width="100%" height="100%" preserveAspectRatio="xMidYMid slice">
  <defs>
    <radialGradient id="navyGlow" cx="65%" cy="40%" r="65%">
      <stop offset="0%" stop-color="#082A7C" stop-opacity="0.8"/>
      <stop offset="50%" stop-color="#03184E" stop-opacity="0.95"/>
      <stop offset="100%" stop-color="#020E2C" stop-opacity="1"/>
    </radialGradient>
    <linearGradient id="goldBeam" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#C59827" stop-opacity="0.25"/>
      <stop offset="50%" stop-color="#DFB752" stop-opacity="0.08"/>
      <stop offset="100%" stop-color="#03184E" stop-opacity="0"/>
    </linearGradient>
    <filter id="blurFilter" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="60"/>
    </filter>
  </defs>

  <rect width="1920" height="1080" fill="url(#navyGlow)"/>

  <!-- Subtle bokeh orbs -->
  <circle cx="1400" cy="350" r="320" fill="#0A369D" opacity="0.25" filter="url(#blurFilter)"/>
  <circle cx="1650" cy="700" r="280" fill="#C59827" opacity="0.12" filter="url(#blurFilter)"/>
  <circle cx="400" cy="800" r="350" fill="#061D57" opacity="0.3" filter="url(#blurFilter)"/>

  <!-- Molecular lattice lines and peptide nodes -->
  <g stroke="#C59827" stroke-opacity="0.18" stroke-width="1.2">
    <!-- Hexagonal lattice -->
    <polygon points="1200,200 1260,235 1260,305 1200,340 1140,305 1140,235" fill="none"/>
    <polygon points="1260,305 1320,340 1320,410 1260,445 1200,410 1200,340" fill="none"/>
    <polygon points="1320,410 1380,445 1380,515 1320,550 1260,515 1260,445" fill="none"/>
    <polygon points="1440,340 1500,375 1500,445 1440,480 1380,445 1380,375" fill="none"/>
    <polygon points="1500,445 1560,480 1560,550 1500,585 1440,550 1440,480" fill="none"/>
    
    <line x1="1260" y1="235" x2="1350" y2="180"/>
    <line x1="1320" y1="550" x2="1390" y2="610"/>
    <line x1="1560" y1="480" x2="1640" y2="430"/>
    <line x1="1140" y1="235" x2="1080" y2="190"/>
    <line x1="1200" y1="410" x2="1120" y2="460"/>
  </g>

  <!-- Glowing nodes -->
  <g fill="#DFB752">
    <circle cx="1200" cy="200" r="3.5" opacity="0.7"/>
    <circle cx="1260" cy="235" r="4.5" opacity="0.8"/>
    <circle cx="1260" cy="305" r="3.5" opacity="0.7"/>
    <circle cx="1200" cy="340" r="5" opacity="0.9"/>
    <circle cx="1140" cy="305" r="3" opacity="0.6"/>
    <circle cx="1320" cy="340" r="4" opacity="0.8"/>
    <circle cx="1320" cy="410" r="5" opacity="0.9"/>
    <circle cx="1380" cy="445" r="4" opacity="0.8"/>
    <circle cx="1500" cy="375" r="3.5" opacity="0.6"/>
    <circle cx="1500" cy="445" r="5" opacity="0.95"/>
    <circle cx="1560" cy="550" r="4" opacity="0.7"/>
  </g>

  <!-- Abstract DNA wave / Bio wave curve -->
  <path d="M-100,600 C 400,450 700,750 1200,550 C 1500,430 1800,650 2050,520" fill="none" stroke="url(#goldBeam)" stroke-width="2"/>
  <path d="M-100,640 C 400,490 700,790 1200,590 C 1500,470 1800,690 2050,560" fill="none" stroke="#C59827" stroke-opacity="0.1" stroke-width="1.5" stroke-dasharray="8 6"/>

  <!-- Minimalist Grid in bottom right -->
  <g stroke="#FFFFFF" stroke-opacity="0.03" stroke-width="1">
    <line x1="1100" y1="650" x2="1850" y2="650"/>
    <line x1="1100" y1="720" x2="1850" y2="720"/>
    <line x1="1100" y1="790" x2="1850" y2="790"/>
    <line x1="1200" y1="600" x2="1200" y2="850"/>
    <line x1="1350" y1="600" x2="1350" y2="850"/>
    <line x1="1500" y1="600" x2="1500" y2="850"/>
    <line x1="1650" y1="600" x2="1650" y2="850"/>
  </g>
</svg>`;

fs.writeFileSync(path.join(publicDir, 'hero', 'hero-bg.svg'), heroBgSvg);

// 3. Generate high quality 3D-styled peptide vial SVG for each product
function createVialSvg(productName, dosage, category, isBlue = false, isSpray = false) {
  const capColor = isSpray ? '#03184E' : '#C59827';
  const capGradient = isSpray 
    ? `<stop offset="0%" stop-color="#1B3374"/><stop offset="50%" stop-color="#03184E"/><stop offset="100%" stop-color="#010A24"/>`
    : `<stop offset="0%" stop-color="#F2D888"/><stop offset="45%" stop-color="#C59827"/><stop offset="100%" stop-color="#805F12"/>`;
  
  const cakeFill = isBlue
    ? `url(#blueCakeGrad)`
    : `url(#goldCakeGrad)`;

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 600" width="100%" height="100%" fill="none">
  <defs>
    <radialGradient id="vialBgGlow" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#F8FAFC" stop-opacity="1"/>
      <stop offset="100%" stop-color="#EBF0F7" stop-opacity="1"/>
    </radialGradient>
    <linearGradient id="capGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      ${capGradient}
    </linearGradient>
    <linearGradient id="goldCakeGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#FDFBF7"/>
      <stop offset="70%" stop-color="#F4EADB"/>
      <stop offset="100%" stop-color="#E2D0B6"/>
    </linearGradient>
    <linearGradient id="blueCakeGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#3A7BD5"/>
      <stop offset="70%" stop-color="#1E4CB0"/>
      <stop offset="100%" stop-color="#0D2E7C"/>
    </linearGradient>
    <linearGradient id="glassReflect" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#FFFFFF" stop-opacity="0.85"/>
      <stop offset="25%" stop-color="#FFFFFF" stop-opacity="0.2"/>
      <stop offset="50%" stop-color="#FFFFFF" stop-opacity="0.05"/>
      <stop offset="75%" stop-color="#FFFFFF" stop-opacity="0.2"/>
      <stop offset="100%" stop-color="#CBD5E1" stop-opacity="0.6"/>
    </linearGradient>
    <linearGradient id="labelGoldBorder" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#E5C368"/>
      <stop offset="100%" stop-color="#9E7719"/>
    </linearGradient>
    <filter id="subtleShadow" x="-10%" y="-10%" width="120%" height="130%">
      <feDropShadow dx="0" dy="18" stdDeviation="16" flood-color="#03184E" flood-opacity="0.12"/>
    </filter>
  </defs>

  <!-- Background Card Field -->
  <rect width="500" height="600" rx="16" fill="url(#vialBgGlow)"/>

  <!-- Minimalist circular backdrop ring -->
  <circle cx="250" cy="300" r="160" stroke="#C59827" stroke-width="1" stroke-opacity="0.18" stroke-dasharray="6 4"/>
  <circle cx="250" cy="300" r="130" stroke="#03184E" stroke-width="0.8" stroke-opacity="0.08"/>

  <!-- Pedestal Shadow -->
  <ellipse cx="250" cy="510" rx="90" ry="16" fill="#03184E" opacity="0.15" filter="url(#subtleShadow)"/>

  <!-- VIAL BODY (Pharmaceutical Glass Bottle) -->
  <g filter="url(#subtleShadow)">
    <!-- Vial Outer Body -->
    <rect x="175" y="210" width="150" height="270" rx="14" fill="#FFFFFF" fill-opacity="0.6" stroke="#94A3B8" stroke-width="1.2"/>
    
    <!-- Vial Shoulder Curve -->
    <path d="M190 210 Q 210 185 225 180 L 275 180 Q 290 185 310 210 Z" fill="#FFFFFF" fill-opacity="0.7" stroke="#94A3B8" stroke-width="1"/>
    
    <!-- Vial Neck -->
    <rect x="225" y="150" width="50" height="32" fill="#E2E8F0" fill-opacity="0.9" stroke="#94A3B8" stroke-width="1"/>

    <!-- Rubber Stopper / Crimp -->
    <rect x="220" y="140" width="60" height="12" rx="3" fill="#334155"/>

    <!-- Gold Aluminum Cap (Flip-off / Crimp) -->
    <rect x="215" y="112" width="70" height="28" rx="6" fill="url(#capGrad)" stroke="#B4861E" stroke-width="1"/>
    <rect x="230" y="106" width="40" height="7" rx="3.5" fill="url(#capGrad)"/>
    <!-- Cap detail grooves -->
    <line x1="220" y1="126" x2="280" y2="126" stroke="#FFFFFF" stroke-opacity="0.4" stroke-width="1"/>

    <!-- Lyophilized Cake (Active Peptide Powder/Matrix) at bottom -->
    <rect x="180" y="420" width="140" height="55" rx="8" fill="${cakeFill}"/>
    <ellipse cx="250" cy="420" rx="70" ry="8" fill="${isBlue ? '#4B88E2' : '#FFFFFF'}" fill-opacity="0.7"/>

    <!-- Glass Highlights (Reflections) -->
    <rect x="175" y="210" width="150" height="270" rx="14" fill="url(#glassReflect)" pointer-events="none"/>
    <path d="M182 220 L 188 220 L 188 470 L 182 470 Z" fill="#FFFFFF" fill-opacity="0.7"/>
    <path d="M312 220 L 316 220 L 316 470 L 312 470 Z" fill="#FFFFFF" fill-opacity="0.4"/>

    <!-- LUXURY PHARMACEUTICAL LABEL -->
    <g transform="translate(182, 245)">
      <!-- Label Background (Matte pearl finish) -->
      <rect width="136" height="155" rx="6" fill="#03184E" stroke="url(#labelGoldBorder)" stroke-width="1.2"/>
      <rect x="4" y="4" width="128" height="147" rx="4" fill="none" stroke="#C59827" stroke-width="0.7" stroke-opacity="0.5"/>
      
      <!-- Label Header Monogram -->
      <polygon points="68,14 74,18 74,25 68,29 62,25 62,18" fill="none" stroke="#C59827" stroke-width="0.9"/>
      <text x="68" y="23" font-family="'Tenor Sans', serif" font-size="7" fill="#DFC066" text-anchor="middle" font-weight="600">E</text>

      <text x="68" y="39" font-family="'Tenor Sans', serif" font-size="9" letter-spacing="2" fill="#FFFFFF" text-anchor="middle" font-weight="600">EVORA</text>
      <line x1="30" y1="44" x2="106" y2="44" stroke="#C59827" stroke-width="0.8"/>

      <!-- Product Name & Dosage on Label -->
      <text x="68" y="64" font-family="'Inter', sans-serif" font-size="${productName.length > 12 ? '8.5' : '10'}" font-weight="700" fill="#DFC066" text-anchor="middle">${productName.toUpperCase()}</text>
      <text x="68" y="80" font-family="'Inter', sans-serif" font-size="9" font-weight="600" fill="#FFFFFF" text-anchor="middle">${dosage}</text>
      
      <!-- Specs & Batch seals -->
      <rect x="18" y="94" width="100" height="16" rx="2" fill="#082363" stroke="#C59827" stroke-width="0.6"/>
      <text x="68" y="105" font-family="'Inter', sans-serif" font-size="6" letter-spacing="1" font-weight="600" fill="#DFC066" text-anchor="middle">PURITY ≥ 99% HPLC</text>

      <text x="68" y="125" font-family="'Inter', sans-serif" font-size="5" letter-spacing="0.8" fill="#94A3B8" text-anchor="middle">BIOMEDICAL LAB GRADE</text>
      <text x="68" y="135" font-family="'Inter', sans-serif" font-size="4.5" fill="#64748B" text-anchor="middle">STERILE • LYOPHILIZED</text>
    </g>
  </g>

  <!-- Clean category tag floating pill at bottom -->
  <rect x="150" y="540" width="200" height="28" rx="14" fill="#FFFFFF" stroke="#E2E8F0" stroke-width="1"/>
  <text x="250" y="558" font-family="'Inter', sans-serif" font-size="9.5" letter-spacing="1" font-weight="600" fill="#03184E" text-anchor="middle">${category.toUpperCase()}</text>
</svg>`;
}

// Map of filenames to products
const productsMap = [
  { file: 'retatrutida.svg', name: 'Retatrutida', dosage: '40mg - 120mg', cat: 'Emagrecedores', blue: false },
  { file: 'tirzepatida.svg', name: 'Tirzepatida', dosage: '60mg - 120mg', cat: 'Emagrecedores', blue: false },
  { file: 'hgh-frag.svg', name: 'HGH-Frag', dosage: '5mg', cat: 'Emagrecedores', blue: false },
  { file: 'aod-9604.svg', name: 'AOD-9604', dosage: '5mg', cat: 'Emagrecedores', blue: false },
  { file: 'tesamorelin.svg', name: 'Tesamorelin', dosage: '10mg', cat: 'Emagrecedores', blue: false },
  { file: 'cbl-514.svg', name: 'CBL-514', dosage: 'Frasco Ampola', cat: 'Emagrecedores', blue: false },
  { file: 'slu-pp-332.svg', name: 'SLU-PP-332', dosage: '50mg', cat: 'Emagrecedores', blue: false },
  { file: 'bpc-157.svg', name: 'BPC-157', dosage: '10mg', cat: 'Recovery', blue: false },
  { file: 'tb-500.svg', name: 'TB-500', dosage: '10mg', cat: 'Recovery', blue: false },
  { file: 'kpv.svg', name: 'KPV', dosage: '10mg', cat: 'Recovery', blue: false },
  { file: 'bpc-tb-blend.svg', name: 'BPC + TB-500', dosage: '10mg Blend', cat: 'Recovery', blue: false },
  { file: 'glow.svg', name: 'Glow Complex', dosage: 'Formulação Exclusiva', cat: 'Recovery', blue: false },
  { file: 'klow.svg', name: 'Klow Complex', dosage: 'Formulação Exclusiva', cat: 'Recovery', blue: false },
  { file: 'epithalon.svg', name: 'Epithalon', dosage: '50mg', cat: 'Longevidade', blue: false },
  { file: 'nad-plus.svg', name: 'NAD+', dosage: '500mg', cat: 'Longevidade', blue: false },
  { file: 'mots-c.svg', name: 'MOTS-C', dosage: '10mg', cat: 'Longevidade', blue: false },
  { file: 'selank.svg', name: 'Selank', dosage: '10mg', cat: 'Neuroproteção', blue: false },
  { file: 'selank-nasal.svg', name: 'Selank Nasal', dosage: '30ml Spray', cat: 'Neuroproteção', blue: false, spray: true },
  { file: 'semax.svg', name: 'Semax', dosage: '30mg', cat: 'Neuroproteção', blue: false },
  { file: 'semax-nasal.svg', name: 'Semax Nasal', dosage: '30ml Spray', cat: 'Neuroproteção', blue: false, spray: true },
  { file: 'pinealon.svg', name: 'Pinealon', dosage: '20mg', cat: 'Neuroproteção', blue: false },
  { file: 'dsip.svg', name: 'DSIP', dosage: '10mg', cat: 'Neuroproteção', blue: false },
  { file: 'ipamorelin.svg', name: 'Ipamorelin', dosage: '5mg', cat: 'Composição Corporal', blue: false },
  { file: 'cjc-ipamorelin.svg', name: 'CJC + Ipamorelin', dosage: '10mg Blend', cat: 'Composição Corporal', blue: false },
  { file: 'tesamorelin-body.svg', name: 'Tesamorelin', dosage: '10mg', cat: 'Composição Corporal', blue: false },
  { file: 'ghk-cu.svg', name: 'GHK-Cu', dosage: '50mg / 100mg', cat: 'Rejuvenescimento', blue: true },
  { file: 'ahk-cu.svg', name: 'AHK-Cu', dosage: '50mg', cat: 'Rejuvenescimento', blue: true },
  { file: 'glutathione.svg', name: 'Glutathione', dosage: '600mg', cat: 'Rejuvenescimento', blue: false },
  { file: 'kisspeptin.svg', name: 'Kisspeptin-10', dosage: '10mg', cat: 'Bem-Estar Sexual', blue: false },
  { file: 'pt-141.svg', name: 'PT-141', dosage: '10mg', cat: 'Bem-Estar Sexual', blue: false }
];

productsMap.forEach(item => {
  const content = createVialSvg(item.name, item.dosage, item.cat, item.blue, item.spray || false);
  fs.writeFileSync(path.join(publicDir, 'products', item.file), content);
});

console.log('All SVGs generated successfully! Total:', productsMap.length);
