"use client";

import React, { useState } from "react";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Categories from "@/components/Categories";
import ProductCatalog from "@/components/ProductCatalog";
import CommercialConditions from "@/components/CommercialConditions";
import FinalCTA from "@/components/FinalCTA";
import WhatsAppButton from "@/components/WhatsAppButton";
import Footer from "@/components/Footer";
import { ProductCategory } from "@/data/products";

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory | "all">("all");

  const handleSelectCategory = (category: ProductCategory | "all") => {
    setSelectedCategory(category);
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#F8F9FB] selection:bg-[#C59827] selection:text-white">
      {/* 1. Header (Sticky) */}
      <Header />

      {/* 2. Hero Section */}
      <Hero />

      {/* 3. Posicionamento EVORA (About) */}
      <About />

      {/* 4. Categorias */}
      <Categories
        selectedCategory={selectedCategory}
        onSelectCategory={handleSelectCategory}
      />

      {/* 5. Catálogo de Produtos (Seleção EVORA) */}
      <ProductCatalog
        selectedCategory={selectedCategory}
        onSelectCategory={handleSelectCategory}
      />

      {/* 6. Condições Comerciais */}
      <CommercialConditions />

      {/* 7. CTA WhatsApp Final */}
      <FinalCTA />

      {/* 8. Footer */}
      <Footer />

      {/* 9. Floating WhatsApp Button (Desktop + Mobile Bar) */}
      <WhatsAppButton />
    </div>
  );
}
