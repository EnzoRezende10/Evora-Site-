import type { Metadata } from "next";
import { Inter, Tenor_Sans } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const tenorSans = Tenor_Sans({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-tenor",
  display: "swap",
});

export const metadata: Metadata = {
  title: "EVORA — Peptídeos de Alta Precisão, Longevidade e Biomedicina",
  description:
    "Mais que peptídeos, um novo padrão de vida. Ciência, inovação e sofisticação para uma nova perspectiva de performance, longevidade e bem-estar.",
  keywords: [
    "EVORA",
    "peptídeos",
    "longevidade",
    "biomedicina",
    "performance",
    "retatrutida",
    "tirzepatida",
    "bpc-157",
    "nad+",
    "ghk-cu",
  ],
  openGraph: {
    title: "EVORA — Mais que peptídeos, um novo padrão de vida",
    description:
      "Precisão científica. Experiência extraordinária. Explore o catálogo de peptídeos avançados da EVORA.",
    type: "website",
    locale: "pt_BR",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR" className={`${inter.variable} ${tenorSans.variable} scroll-smooth`}>
      <body className="bg-[#F8F9FB] text-[#0F141D] font-sans antialiased selection:bg-[#C59827] selection:text-white min-h-screen">
        {children}
      </body>
    </html>
  );
}
