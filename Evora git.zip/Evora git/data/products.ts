export type ProductCategory =
  | "Emagrecedores"
  | "Recovery"
  | "Longevidade & Performance"
  | "Neuroproteção, Foco, Memória"
  | "Composição Corporal & Ganho de Massa"
  | "Beleza & Rejuvenescimento"
  | "Bem-Estar Sexual";

export interface ProductTechnicalInfo {
  purity: string;
  storage: string;
  mechanism: string;
  class: string;
}

export interface Product {
  id: number;
  name: string;
  dosage: string;
  category: ProductCategory;
  price: number;
  priceFormatted: string;
  image: string;
  description: string;
  presentation: string;
  technicalInfo: ProductTechnicalInfo;
  featured?: boolean;
}

export const CATEGORIES: {
  id: ProductCategory;
  label: string;
  icon: string;
  description: string;
}[] = [
  {
    id: "Emagrecedores",
    label: "Emagrecedores",
    icon: "Flame",
    description: "Modulação metabólica avançada, queima lipídica profunda e otimização incretínica de alta precisão."
  },
  {
    id: "Recovery",
    label: "Recovery",
    icon: "ShieldCheck",
    description: "Regeneração tecidual acelerada, angiogênese, reparação de ligamentos e controle inflamatório sistêmico."
  },
  {
    id: "Longevidade & Performance",
    label: "Longevidade & Performance",
    icon: "Sparkles",
    description: "Otimização mitocondrial, preservação dos telômeros e extensão de vitalidade bioenergética."
  },
  {
    id: "Neuroproteção, Foco, Memória",
    label: "Neuroproteção, Foco, Memória",
    icon: "Brain",
    description: "Equilíbrio neuroquímico, clareza cognitiva executiva, suporte ansiolítico e restauração circadiana."
  },
  {
    id: "Composição Corporal & Ganho de Massa",
    label: "Composição Corporal & Ganho de Massa",
    icon: "Activity",
    description: "Estímulo somatotrófico biomimético pulsátil para densidade muscular limpa e queima visceral."
  },
  {
    id: "Beleza & Rejuvenescimento",
    label: "Beleza & Rejuvenescimento",
    icon: "Gem",
    description: "Síntese de colágeno dérmico, remodelamento de matriz extracelular e defesa antioxidante mestre."
  },
  {
    id: "Bem-Estar Sexual",
    label: "Bem-Estar Sexual",
    icon: "HeartPulse",
    description: "Ativação neuroendócrina central do eixo gonadal e amplificação da libido e vitalidade íntima."
  }
];

export const PRODUCTS: Product[] = [
  // ==========================================
  // 1. EMAGRECEDORES
  // ==========================================
  {
    id: 1,
    name: "Retatrutida",
    dosage: "40 mg",
    category: "Emagrecedores",
    price: 990,
    priceFormatted: "R$ 990",
    image: "/products/retatrutida.svg",
    description: "Tri-agonista dos receptores GLP-1, GIP e Glucagon. A mais avançada fronteira científica na modulação ponderal e esteatose hepática.",
    presentation: "Frasco ampola liofilizado com selo de segurança farmacêutica",
    technicalInfo: {
      purity: "≥ 99.4% (HPLC)",
      storage: "Conservar de 2°C a 8°C ao abrigo de luz",
      mechanism: "Co-agonismo triplo GLP-1R / GIPR / GCGR",
      class: "Peptídeo de Modulação Metabólica Multialvo"
    },
    featured: true
  },
  {
    id: 2,
    name: "Retatrutida",
    dosage: "60 mg",
    category: "Emagrecedores",
    price: 1290,
    priceFormatted: "R$ 1.290",
    image: "/products/retatrutida.svg",
    description: "Dose intermediária de 60mg desenvolvida para máxima eficiência e flexibilidade em protocolos metabólicos de média e longa duração.",
    presentation: "Frasco ampola liofilizado sob vácuo estéril",
    technicalInfo: {
      purity: "≥ 99.5% (HPLC)",
      storage: "Conservar entre 2°C e 8°C",
      mechanism: "Termogênese mitocondrial e saciedade central duradoura",
      class: "Tri-agonista Incretínico de Alta Potência"
    },
    featured: true
  },
  {
    id: 3,
    name: "Retatrutida",
    dosage: "120 mg",
    category: "Emagrecedores",
    price: 1850,
    priceFormatted: "R$ 1.850",
    image: "/products/retatrutida.svg",
    description: "Apresentação concentrada de 120mg com pureza molecular certificada para máxima conveniência e custo-benefício em protocolos contínuos.",
    presentation: "Frasco ampola liofilizado de grau farmacêutico ultra-puro",
    technicalInfo: {
      purity: "≥ 99.6% (HPLC)",
      storage: "2°C a 8°C. Manter em temperatura controlada",
      mechanism: "Ativação sinérgica GLP-1/GIP/Glucagon",
      class: "Tri-agonista Avançado de Alta Concentração"
    },
    featured: false
  },
  {
    id: 4,
    name: "Tirzepatida",
    dosage: "60 mg",
    category: "Emagrecedores",
    price: 790,
    priceFormatted: "R$ 790",
    image: "/products/tirzepatida.svg",
    description: "Co-agonista dual dos receptores GIP e GLP-1. Excelente controle glicêmico, saciedade profunda e regulação metabólica sistêmica.",
    presentation: "Frasco ampola liofilizado com lacre estéril",
    technicalInfo: {
      purity: "≥ 99.3% (HPLC)",
      storage: "Refrigerado de 2°C a 8°C",
      mechanism: "Ativação combinada de receptores incretínicos GIP/GLP-1",
      class: "Polipeptídeo Incretínico Sintético Dual"
    },
    featured: true
  },
  {
    id: 5,
    name: "Tirzepatida",
    dosage: "120 mg",
    category: "Emagrecedores",
    price: 1450,
    priceFormatted: "R$ 1.450",
    image: "/products/tirzepatida.svg",
    description: "Versão concentrada de 120mg para suporte metabólico de alto padrão, garantindo consistência terapêutica em protocolos prolongados.",
    presentation: "Frasco ampola selado com septo de butil inerte",
    technicalInfo: {
      purity: "≥ 99.4% (HPLC)",
      storage: "Conservar entre 2°C e 8°C",
      mechanism: "Bio-sinalização simultânea GIP/GLP-1 prolongada",
      class: "Incretina Sintética de Longa Ação"
    },
    featured: false
  },
  {
    id: 6,
    name: "HGH-FRAG",
    dosage: "15 mg",
    category: "Emagrecedores",
    price: 740,
    priceFormatted: "R$ 740",
    image: "/products/hgh-frag.svg",
    description: "Fração C-terminal do hormônio do crescimento (176-191). Promove lipólise direta potente sem interferir na glicose sérica ou sensibilidade insulínica.",
    presentation: "Frasco ampola liofilizado estéril de 15mg",
    technicalInfo: {
      purity: "≥ 99.2% (HPLC)",
      storage: "2°C a 8°C ao abrigo de radiação luminosa",
      mechanism: "Estímulo lipolítico seletivo e inibição da lipogênese adiposa",
      class: "Fragmento Polipeptídico Somatotrófico Puro"
    },
    featured: false
  },
  {
    id: 7,
    name: "AOD-9604",
    dosage: "10 mg",
    category: "Emagrecedores",
    price: 590,
    priceFormatted: "R$ 590",
    image: "/products/aod-9604.svg",
    description: "Peptídeo modificado derivado do GH para mobilização lipídica seletiva e apoio à regeneração de cartilagem condral.",
    presentation: "Frasco ampola liofilizado em atmosfera inerte",
    technicalInfo: {
      purity: "≥ 99.1% (HPLC)",
      storage: "Refrigerar de 2°C a 8°C",
      mechanism: "Queima lipídica direcionada sem impacto no apetite",
      class: "Análogo de Fragmento Lipolítico Estabilizado"
    },
    featured: false
  },
  {
    id: 8,
    name: "Tesamorelin",
    dosage: "10 mg",
    category: "Emagrecedores",
    price: 590,
    priceFormatted: "R$ 590",
    image: "/products/tesamorelin.svg",
    description: "Análogo do GHRH com notável capacidade de mobilização e eliminação de gordura visceral profunda intra-abdominal.",
    presentation: "Frasco ampola liofilizado estéril",
    technicalInfo: {
      purity: "≥ 99.4% (HPLC)",
      storage: "2°C a 8°C",
      mechanism: "Bioestímulo à secreção pulsátil de GH endógeno",
      class: "Fator Liberador de Hormônio do Crescimento Estabilizado"
    },
    featured: false
  },
  {
    id: 9,
    name: "CBL-514",
    dosage: "60 mg",
    category: "Emagrecedores",
    price: 670,
    priceFormatted: "R$ 670",
    image: "/products/cbl-514.svg",
    description: "Inovação injetável indutora de apoptose em adipócitos maduros. Modelagem de gordura subcutânea sem necrose tecidual ou dor residual.",
    presentation: "Frasco ampola estéril de 60mg",
    technicalInfo: {
      purity: "≥ 99.2% (HPLC)",
      storage: "2°C a 8°C em ambiente estéril",
      mechanism: "Apoptose seletiva de adipócitos maduros",
      class: "Agente Lipolítico Apoptótico Específico"
    },
    featured: false
  },
  {
    id: 10,
    name: "SLU-PP-332",
    dosage: "10 mg",
    category: "Emagrecedores",
    price: 590,
    priceFormatted: "R$ 590",
    image: "/products/slu-pp-332.svg",
    description: "Agonista dos receptores ERRα/ERRγ. Induz a biogênese mitocondrial muscular mimetizando os benefícios celulares do exercício aeróbico intenso.",
    presentation: "Frasco com pó liofilizado ultrapuro",
    technicalInfo: {
      purity: "≥ 99.5% (HPLC)",
      storage: "Local seco e refrigerado a 2°C - 8°C",
      mechanism: "Ativação direta da cascata mitocondrial ERR",
      class: "Mimético Molecular de Exercício Aeróbico"
    },
    featured: false
  },

  // ==========================================
  // 2. RECOVERY
  // ==========================================
  {
    id: 11,
    name: "BPC-157",
    dosage: "10 mg",
    category: "Recovery",
    price: 540,
    priceFormatted: "R$ 540",
    image: "/products/bpc-157.svg",
    description: "O mais consagrado pentadecapeptídeo regenerativo. Estimula angiogênese rápida e reparação de tendões, ligamentos, músculos e barreira intestinal.",
    presentation: "Frasco ampola liofilizado com selo protetor",
    technicalInfo: {
      purity: "≥ 99.5% (HPLC)",
      storage: "2°C a 8°C após reconstituição",
      mechanism: "Up-regulation do receptor VEGF e fatores de migração fibroblástica",
      class: "Pentadecapeptídeo Cito-protetor e Cicatrizante"
    },
    featured: true
  },
  {
    id: 12,
    name: "TB-500",
    dosage: "10 mg",
    category: "Recovery",
    price: 540,
    priceFormatted: "R$ 540",
    image: "/products/tb-500.svg",
    description: "Fração peptídica sintética da Timosina Beta-4. Atua na polimerização de actina, conferindo flexibilidade tecidual e angiogênese em áreas de lesão.",
    presentation: "Frasco ampola liofilizado estéril",
    technicalInfo: {
      purity: "≥ 99.3% (HPLC)",
      storage: "2°C a 8°C",
      mechanism: "Sequestro e regulação de actina celular para migração tecidual",
      class: "Peptídeo de Mobilidade Celular e Regeneração"
    },
    featured: false
  },
  {
    id: 13,
    name: "KPV",
    dosage: "10 mg",
    category: "Recovery",
    price: 780,
    priceFormatted: "R$ 780",
    image: "/products/kpv.svg",
    description: "Tripeptídeo com potente ação anti-inflamatória e antimicrobiana. Excelente eficácia na mucosa intestinal e modulação de dermatites e inflamações sistêmicas.",
    presentation: "Frasco ampola liofilizado",
    technicalInfo: {
      purity: "≥ 99.4% (HPLC)",
      storage: "Conservar entre 2°C e 8°C",
      mechanism: "Inibição de NF-κB e atenuação de citocinas inflamatórias",
      class: "Tripeptídeo Imunomodulador e Anti-inflamatório"
    },
    featured: false
  },
  {
    id: 14,
    name: "BPC-157 + TB-500",
    dosage: "10 mg",
    category: "Recovery",
    price: 540,
    priceFormatted: "R$ 540",
    image: "/products/bpc-tb-blend.svg",
    description: "Blend sinérgico clássico combinando a cicatrização microvascular do BPC-157 com a regeneração miofascial do TB-500.",
    presentation: "Frasco ampola co-liofilizado sob nitrogênio",
    technicalInfo: {
      purity: "≥ 99.4% (HPLC)",
      storage: "2°C a 8°C",
      mechanism: "Ação conjunta angiogênica e remodelamento da matriz extracelular",
      class: "Complexo Bicomposto de Recuperação Integrada"
    },
    featured: true
  },
  {
    id: 15,
    name: "BPC-157 + TB-500",
    dosage: "20 mg",
    category: "Recovery",
    price: 840,
    priceFormatted: "R$ 840",
    image: "/products/bpc-tb-blend.svg",
    description: "Apresentação concentrada de 20mg da sinergia BPC-157 + TB-500, desenvolvida para atletas e pacientes em recuperação de lesões complexas.",
    presentation: "Frasco ampola co-liofilizado de alta capacidade",
    technicalInfo: {
      purity: "≥ 99.5% (HPLC)",
      storage: "Conservar de 2°C a 8°C",
      mechanism: "Potencialização de tenócitos e regeneração muscular acelerada",
      class: "Complexo Bicomposto Alta Concentração"
    },
    featured: false
  },
  {
    id: 16,
    name: "GLOW",
    dosage: "70 mg",
    category: "Recovery",
    price: 580,
    priceFormatted: "R$ 580",
    image: "/products/glow.svg",
    description: "Complexo avançado de 70mg para revitalização de tecidos conjuntivos, elasticidade articular, hidratação profunda e renovação celular.",
    presentation: "Frasco ampola liofilizado biocompatível",
    technicalInfo: {
      purity: "≥ 99.2% (HPLC)",
      storage: "2°C a 8°C ao abrigo de calor e luz",
      mechanism: "Estímulo à síntese de colágeno e bioestimulação tecidual",
      class: "Complexo Peptídico Multicomponente de Revitalização"
    },
    featured: false
  },
  {
    id: 17,
    name: "KLOW",
    dosage: "80 mg",
    category: "Recovery",
    price: 680,
    priceFormatted: "R$ 680",
    image: "/products/klow.svg",
    description: "Fórmula de alta potência de 80mg focada na neutralização de estresse inflamatório crônico pós-esforço, alívio de fadiga e equilíbrio muscular.",
    presentation: "Frasco ampola estéril de 80mg",
    technicalInfo: {
      purity: "≥ 99.3% (HPLC)",
      storage: "Conservar entre 2°C e 8°C",
      mechanism: "Atenuação de cascatas inflamatórias e reparo celular rápido",
      class: "Blend Peptídico Anti-Fadiga e Reparação Sistêmica"
    },
    featured: false
  },

  // ==========================================
  // 3. LONGEVIDADE & PERFORMANCE
  // ==========================================
  {
    id: 18,
    name: "Epithalon",
    dosage: "50 mg",
    category: "Longevidade & Performance",
    price: 790,
    priceFormatted: "R$ 790",
    image: "/products/epithalon.svg",
    description: "Tetrapeptídeo mimético da epitalamina epifisária. Conhecido por estimular a expressão da telomerase e normalizar ritmos circadianos e hormonais.",
    presentation: "Frasco ampola liofilizado estéril de 50mg",
    technicalInfo: {
      purity: "≥ 99.5% (HPLC)",
      storage: "Refrigerado a 2°C - 8°C",
      mechanism: "Preservação e elongação telomérica e restauração de melatonina",
      class: "Bio-regulador Epifisário Telomérico"
    },
    featured: true
  },
  {
    id: 19,
    name: "NAD+",
    dosage: "500 mg",
    category: "Longevidade & Performance",
    price: 490,
    priceFormatted: "R$ 490",
    image: "/products/nad-plus.svg",
    description: "Nicotinamida Adenina Dinucleotídeo pura em alta dose de 500mg. Cofator bioenergético mitocondrial, ativador de sirtuínas e reparador de DNA celular.",
    presentation: "Frasco ampola liofilizado de 500mg",
    technicalInfo: {
      purity: "≥ 99.6% (HPLC)",
      storage: "Rigidamente refrigerado a 2°C - 6°C",
      mechanism: "Fosforilação oxidativa mitocondrial e ativação de SIRT1 a SIRT7",
      class: "Coenzima Metabólica e Regenerador Mitocondrial"
    },
    featured: true
  },
  {
    id: 20,
    name: "Mots-C",
    dosage: "40 mg",
    category: "Longevidade & Performance",
    price: 750,
    priceFormatted: "R$ 750",
    image: "/products/mots-c.svg",
    description: "Peptídeo mitocondrial codificado (MDP) na dosagem de 40mg. Regula a homeostase metabólica muscular e potencializa a resistência física celular.",
    presentation: "Frasco ampola liofilizado estéril de 40mg",
    technicalInfo: {
      purity: "≥ 99.2% (HPLC)",
      storage: "2°C a 8°C protegido da luz",
      mechanism: "Ativação da via AMPK e otimização da oxidação de ácidos graxos",
      class: "Peptídeo de Sinalização Mitocondrial (MDP)"
    },
    featured: false
  },

  // ==========================================
  // 4. NEUROPROTEÇÃO, FOCO, MEMÓRIA
  // ==========================================
  {
    id: 21,
    name: "Selank",
    dosage: "10 mg",
    category: "Neuroproteção, Foco, Memória",
    price: 590,
    priceFormatted: "R$ 590",
    image: "/products/selank.svg",
    description: "Heptapeptídeo regulador com efeitos ansiolíticos e neurotróficos. Modula o BDNF sem provocar sonolência, dependência ou letargia.",
    presentation: "Frasco ampola liofilizado de 10mg",
    technicalInfo: {
      purity: "≥ 99.4% (HPLC)",
      storage: "2°C a 8°C",
      mechanism: "Modulação alostérica gabaérgica e expressão de BDNF no córtex",
      class: "Ansiolítico Peptídico Nootrópico"
    },
    featured: true
  },
  {
    id: 22,
    name: "Selank Nasal",
    dosage: "Spray Nasal Calibrado",
    category: "Neuroproteção, Foco, Memória",
    price: 680,
    priceFormatted: "R$ 680",
    image: "/products/selank-nasal.svg",
    description: "Apresentação em spray nasal calibrado para absorção olfatória transcribriforme direta ao sistema nervoso central, conferindo serenidade e foco.",
    presentation: "Frasco atomizador estéril com micro-nebulização",
    technicalInfo: {
      purity: "≥ 99.2% (HPLC)",
      storage: "Refrigerar de 2°C a 8°C",
      mechanism: "Transporte olfatório direto e biodisponibilidade cerebral imediata",
      class: "Formulação Transmucosa Nootrópica"
    },
    featured: false
  },
  {
    id: 23,
    name: "Semax",
    dosage: "10 mg",
    category: "Neuroproteção, Foco, Memória",
    price: 590,
    priceFormatted: "R$ 590",
    image: "/products/semax.svg",
    description: "Peptídeo análogo do ACTH (4-10) com ação nootrópica e neurogênica. Eleva a concentração mental, agilidade executiva e consolidação de memória.",
    presentation: "Frasco ampola liofilizado de 10mg",
    technicalInfo: {
      purity: "≥ 99.4% (HPLC)",
      storage: "2°C a 8°C",
      mechanism: "Up-regulation seletiva de BDNF e NGF no hipocampo",
      class: "Nootrópico Neurotrófico Avançado"
    },
    featured: true
  },
  {
    id: 24,
    name: "Semax Nasal",
    dosage: "Spray Nasal Calibrado",
    category: "Neuroproteção, Foco, Memória",
    price: 680,
    priceFormatted: "R$ 680",
    image: "/products/semax-nasal.svg",
    description: "Versão nasal calibrada para clareza e foco intelectual imediato. Excelente biodisponibilidade e facilidade de aplicação.",
    presentation: "Frasco dosador nasal com ponta atomizadora esterilizada",
    technicalInfo: {
      purity: "≥ 99.1% (HPLC)",
      storage: "Conservar refrigerado a 2°C - 8°C",
      mechanism: "Absorção via mucosa olfatória e estímulo dopaminérgico seletivo",
      class: "Spray Nootrópico de Alta Precisão"
    },
    featured: false
  },
  {
    id: 25,
    name: "Pinealon",
    dosage: "10 mg",
    category: "Neuroproteção, Foco, Memória",
    price: 590,
    priceFormatted: "R$ 590",
    image: "/products/pinealon.svg",
    description: "Tripeptídeo bio-regulador neural curto. Protege o parênquima cerebral contra estresse oxidativo e hipóxia e otimiza a comunicação sináptica.",
    presentation: "Frasco ampola liofilizado estéril de 10mg",
    technicalInfo: {
      purity: "≥ 99.5% (HPLC)",
      storage: "Conservar a 2°C - 8°C",
      mechanism: "Regulação da expressão gênica neural e proteção contra apoptose",
      class: "Bio-regulador Celular Neural Curto"
    },
    featured: false
  },
  {
    id: 26,
    name: "DSIP",
    dosage: "10 mg",
    category: "Neuroproteção, Foco, Memória",
    price: 590,
    priceFormatted: "R$ 590",
    image: "/products/dsip.svg",
    description: "Delta Sleep-Inducing Peptide. Induz ondas lentas delta no sono profundo, restaurando a arquitetura fisiológica e atenuando o estresse crônico.",
    presentation: "Frasco ampola liofilizado de 10mg",
    technicalInfo: {
      purity: "≥ 99.3% (HPLC)",
      storage: "Conservar entre 2°C e 8°C",
      mechanism: "Bioindução de sono delta profundo reparador e homeostase circadiana",
      class: "Neuromodulador Circadiano e do Sono"
    },
    featured: false
  },

  // ==========================================
  // 5. COMPOSIÇÃO CORPORAL & GANHO DE MASSA
  // ==========================================
  {
    id: 27,
    name: "Ipamorelin",
    dosage: "10 mg",
    category: "Composição Corporal & Ganho de Massa",
    price: 590,
    priceFormatted: "R$ 590",
    image: "/products/ipamorelin.svg",
    description: "Pentapeptídeo secretagogo seletivo de GH (GHRP). Estímulo pulsátil limpo sem elevação de cortisol, apetite excessivo ou prolactina.",
    presentation: "Frasco ampola liofilizado de 10mg",
    technicalInfo: {
      purity: "≥ 99.5% (HPLC)",
      storage: "2°C a 8°C",
      mechanism: "Agonismo seletivo sobre o receptor GHS-R1a somatotrófico",
      class: "Secretagogo Seletivo de Hormônio do Crescimento"
    },
    featured: true
  },
  {
    id: 28,
    name: "CJC no Dac + Ipamorelin",
    dosage: "10 mg",
    category: "Composição Corporal & Ganho de Massa",
    price: 590,
    priceFormatted: "R$ 590",
    image: "/products/cjc-ipamorelin.svg",
    description: "Sinergia somatotrófica de excelência: análogo GHRH (sem DAC) combinado ao Ipamorelin para amplificação máxima da liberação natural de GH.",
    presentation: "Frasco ampola co-liofilizado estéril de 10mg",
    technicalInfo: {
      purity: "≥ 99.4% (HPLC)",
      storage: "Conservar entre 2°C e 8°C",
      mechanism: "Ação simultânea em receptores GHRH e Ghrelin/GHS",
      class: "Complexo Somatotrófico Dual Biomimético"
    },
    featured: true
  },
  {
    id: 29,
    name: "Tesamorelin",
    dosage: "10 mg",
    category: "Composição Corporal & Ganho de Massa",
    price: 590,
    priceFormatted: "R$ 590",
    image: "/products/tesamorelin-body.svg",
    description: "Análogo de GHRH de alta especificidade para preservação de massa muscular densa, suporte anabólico fisiológico e redução lipídica visceral.",
    presentation: "Frasco ampola liofilizado estéril de 10mg",
    technicalInfo: {
      purity: "≥ 99.3% (HPLC)",
      storage: "Conservar refrigerado a 2°C - 8°C",
      mechanism: "Bio-sinalização agonista sobre a hipófise anterior",
      class: "Peptídeo Biomimético da Série GHRH"
    },
    featured: false
  },

  // ==========================================
  // 6. BELEZA & REJUVENESCIMENTO
  // ==========================================
  {
    id: 30,
    name: "GHK-CU",
    dosage: "50 mg",
    category: "Beleza & Rejuvenescimento",
    price: 490,
    priceFormatted: "R$ 490",
    image: "/products/ghk-cu.svg",
    description: "Tripeptídeo de cobre com coloração azul royal natural. Estimula fibroblastos dérmicos, síntese de colágeno tipos I e III e elastina tecidual.",
    presentation: "Frasco ampola liofilizado azul royal de 50mg",
    technicalInfo: {
      purity: "≥ 99.5% (HPLC)",
      storage: "2°C a 8°C",
      mechanism: "Remodelamento da matriz dérmica e ativação de células-tronco epiteliais",
      class: "Complexo Peptídico Cobre-Biomimético"
    },
    featured: true
  },
  {
    id: 31,
    name: "GHK-CU",
    dosage: "100 mg",
    category: "Beleza & Rejuvenescimento",
    price: 590,
    priceFormatted: "R$ 590",
    image: "/products/ghk-cu.svg",
    description: "Apresentação concentrada de 100mg para protocolos dermatológicos corporais, rejuvenescimento intensivo e terapia capilar folicular.",
    presentation: "Frasco ampola selado a vácuo com pó azul royal puro",
    technicalInfo: {
      purity: "≥ 99.6% (HPLC)",
      storage: "2°C a 8°C ao abrigo de umidade",
      mechanism: "Estímulo avançado de glicosaminoglicanos e colágeno",
      class: "Tripeptídeo de Cobre Concentrado"
    },
    featured: false
  },
  {
    id: 32,
    name: "AHK-CU",
    dosage: "50 mg",
    category: "Beleza & Rejuvenescimento",
    price: 690,
    priceFormatted: "R$ 690",
    image: "/products/ahk-cu.svg",
    description: "Peptídeo de cobre especializado em bioestimulação folicular capilar, angiogênese dérmica no couro cabeludo e combate à miniaturização capilar.",
    presentation: "Frasco ampola liofilizado de 50mg",
    technicalInfo: {
      purity: "≥ 99.3% (HPLC)",
      storage: "2°C a 8°C",
      mechanism: "Proliferação celular da papila dérmica e microcirculação folicular",
      class: "Peptídeo Bioativo Capilar Tricológico"
    },
    featured: false
  },
  {
    id: 33,
    name: "Glutathione",
    dosage: "1500 mg",
    category: "Beleza & Rejuvenescimento",
    price: 490,
    priceFormatted: "R$ 490",
    image: "/products/glutathione.svg",
    description: "Glutationa reduzida na dosagem nobre de 1500mg. O antioxidante mestre do organismo humano para desintoxicação hepática, uniformização e luminosidade cutânea.",
    presentation: "Frasco ampola liofilizado estéril de 1500mg",
    technicalInfo: {
      purity: "≥ 99.7% (HPLC)",
      storage: "Refrigerar de 2°C a 8°C",
      mechanism: "Inibição de tirosinase dérmica e neutralização de radicais livres",
      class: "Tripeptídeo Antioxidante Mestre Endógeno"
    },
    featured: true
  },

  // ==========================================
  // 7. BEM-ESTAR SEXUAL
  // ==========================================
  {
    id: 34,
    name: "Kisspeptin",
    dosage: "10 mg",
    category: "Bem-Estar Sexual",
    price: 540,
    priceFormatted: "R$ 540",
    image: "/products/kisspeptin.svg",
    description: "Decapeptídeo regulador central do eixo hipotálamo-hipófise-gonadal. Estimula a liberação pulsátil de GnRH e a vitalidade hormonal intrínseca.",
    presentation: "Frasco ampola liofilizado de 10mg",
    technicalInfo: {
      purity: "≥ 99.3% (HPLC)",
      storage: "Conservar a 2°C - 8°C",
      mechanism: "Agonismo direto no receptor KISS1R (GPR54) hipotalâmico",
      class: "Decapeptídeo Neuroendócrino Regulador Gonadal"
    },
    featured: true
  },
  {
    id: 35,
    name: "PT-141",
    dosage: "10 mg",
    category: "Bem-Estar Sexual",
    price: 540,
    priceFormatted: "R$ 540",
    image: "/products/pt-141.svg",
    description: "Bremelanotide de alta pureza. Atua no sistema nervoso central via receptores de melanocortina (MC3R/MC4R) para potencializar o desejo e a função erétil.",
    presentation: "Frasco ampola liofilizado farmacêutico de 10mg",
    technicalInfo: {
      purity: "≥ 99.4% (HPLC)",
      storage: "2°C a 8°C",
      mechanism: "Ativação neuroquímica nos núcleos do hipotálamo medial",
      class: "Agonista Sintético do Receptor de Melanocortina"
    },
    featured: true
  }
];
