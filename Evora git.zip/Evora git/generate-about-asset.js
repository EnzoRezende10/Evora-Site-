const fs = require('fs');
const path = require('path');

const publicDir = 'C:/Users/enzo.augusto/.gemini/antigravity/scratch/evora/public';

const aboutIllustrationSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 650" width="100%" height="100%" fill="none">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#03184E"/>
      <stop offset="50%" stop-color="#052168"/>
      <stop offset="100%" stop-color="#021035"/>
    </linearGradient>
    <linearGradient id="goldAcc" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#F2D888"/>
      <stop offset="50%" stop-color="#C59827"/>
      <stop offset="100%" stop-color="#9E7719"/>
    </linearGradient>
    <radialGradient id="labLight" cx="50%" cy="30%" r="50%">
      <stop offset="0%" stop-color="#2451B2" stop-opacity="0.4"/>
      <stop offset="100%" stop-color="#03184E" stop-opacity="0"/>
    </radialGradient>
    <filter id="cardGlow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="30"/>
    </filter>
  </defs>

  <!-- Card background -->
  <rect width="800" height="650" rx="24" fill="url(#bgGrad)"/>
  <rect x="2" y="2" width="796" height="646" rx="22" stroke="url(#goldAcc)" stroke-width="1.5" stroke-opacity="0.4"/>

  <!-- Subtle glow -->
  <circle cx="400" cy="250" r="220" fill="url(#labLight)"/>

  <!-- Isometric / Architectural laboratory & peptide matrix lines -->
  <g stroke="#C59827" stroke-opacity="0.25" stroke-width="1.2">
    <!-- Outer hexagon -->
    <polygon points="400,90 560,180 560,370 400,460 240,370 240,180" fill="none"/>
    <!-- Inner nested hexagon -->
    <polygon points="400,140 515,205 515,345 400,410 285,345 285,205" fill="#0A2870" fill-opacity="0.3"/>
    <circle cx="400" cy="275" r="95" stroke="#FFFFFF" stroke-opacity="0.15" stroke-dasharray="4 4"/>
  </g>

  <!-- Central Scientific Hologram / Peptide Helix Structure -->
  <g>
    <!-- Strands -->
    <path d="M350,160 Q400,200 450,230 T350,300 T450,370" fill="none" stroke="url(#goldAcc)" stroke-width="3" stroke-linecap="round"/>
    <path d="M450,160 Q400,200 350,230 T450,300 T350,370" fill="none" stroke="#60A5FA" stroke-width="2.5" stroke-linecap="round" opacity="0.8"/>
    
    <!-- Connectors -->
    <line x1="375" y1="180" x2="425" y2="180" stroke="#DFB752" stroke-width="1.5" stroke-opacity="0.7"/>
    <line x1="400" y1="215" x2="400" y2="245" stroke="#DFB752" stroke-width="1.5" stroke-opacity="0.7"/>
    <line x1="365" y1="265" x2="435" y2="265" stroke="#DFB752" stroke-width="1.5" stroke-opacity="0.7"/>
    <line x1="390" y1="335" x2="410" y2="335" stroke="#DFB752" stroke-width="1.5" stroke-opacity="0.7"/>

    <!-- Molecule nodes -->
    <circle cx="350" cy="160" r="7" fill="#C59827"/>
    <circle cx="450" cy="160" r="6" fill="#93C5FD"/>
    <circle cx="450" cy="230" r="7" fill="#DFB752"/>
    <circle cx="350" cy="230" r="6" fill="#60A5FA"/>
    <circle cx="350" cy="300" r="7" fill="#C59827"/>
    <circle cx="450" cy="300" r="6" fill="#93C5FD"/>
    <circle cx="450" cy="370" r="7" fill="#DFB752"/>
    <circle cx="350" cy="370" r="6" fill="#60A5FA"/>
  </g>

  <!-- Floating telemetry badges -->
  <g transform="translate(100, 480)">
    <rect width="180" height="70" rx="12" fill="#021035" fill-opacity="0.85" stroke="#C59827" stroke-width="1" stroke-opacity="0.4"/>
    <text x="20" y="28" font-family="'Inter', sans-serif" font-size="10" letter-spacing="1.5" fill="#C59827" font-weight="600">CERTIFICAÇÃO</text>
    <text x="20" y="52" font-family="'Tenor Sans', serif" font-size="20" fill="#FFFFFF" font-weight="600">HPLC ≥ 99%</text>
  </g>

  <g transform="translate(310, 480)">
    <rect width="180" height="70" rx="12" fill="#021035" fill-opacity="0.85" stroke="#C59827" stroke-width="1" stroke-opacity="0.4"/>
    <text x="20" y="28" font-family="'Inter', sans-serif" font-size="10" letter-spacing="1.5" fill="#C59827" font-weight="600">ESTABILIDADE</text>
    <text x="20" y="52" font-family="'Tenor Sans', serif" font-size="20" fill="#FFFFFF" font-weight="600">CADEIA FRIA</text>
  </g>

  <g transform="translate(520, 480)">
    <rect width="180" height="70" rx="12" fill="#021035" fill-opacity="0.85" stroke="#C59827" stroke-width="1" stroke-opacity="0.4"/>
    <text x="20" y="28" font-family="'Inter', sans-serif" font-size="10" letter-spacing="1.5" fill="#C59827" font-weight="600">PADRÃO</text>
    <text x="20" y="52" font-family="'Tenor Sans', serif" font-size="20" fill="#FFFFFF" font-weight="600">GMP PHARMA</text>
  </g>
</svg>`;

fs.writeFileSync(path.join(publicDir, 'hero', 'lab-precision.svg'), aboutIllustrationSvg);
console.log('About illustration created');
