const fs = require('fs');
const path = require('path');

const publicDir = 'C:/Users/enzo.augusto/.gemini/antigravity/scratch/evora/public';

// 1. Official EVORA Wordmark according to Brandbook (Light Background Master)
// EVOR in Nocturne Navy (#031B4E), and A with gold right terminal stroke
const logoMasterSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 540 140" fill="none">
  <defs>
    <linearGradient id="evoraGoldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#E7C976" />
      <stop offset="35%" stop-color="#C59827" />
      <stop offset="70%" stop-color="#DFB752" />
      <stop offset="100%" stop-color="#936F15" />
    </linearGradient>
    <linearGradient id="evoraGoldSub" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#C59827" />
      <stop offset="100%" stop-color="#DFC066" />
    </linearGradient>
  </defs>

  <g transform="translate(10, 15)">
    <!-- Letter E -->
    <path d="M 30 20 L 78 20 L 78 28 L 40 28 L 40 50 L 74 50 L 74 58 L 40 58 L 40 82 L 80 82 L 80 90 L 30 90 Z" fill="#031B4E" />

    <!-- Letter V -->
    <path d="M 108 20 L 120 20 L 145 76 L 170 20 L 182 20 L 152 90 L 138 90 Z" fill="#031B4E" />

    <!-- Letter O (Perfect circle as per brandbook) -->
    <path d="M 248 18 C 273 18 293 34 293 55 C 293 76 273 92 248 92 C 223 92 203 76 203 55 C 203 34 223 18 248 18 Z M 248 27 C 267 27 282 39 282 55 C 282 71 267 83 248 83 C 229 83 214 71 214 55 C 214 39 229 27 248 27 Z" fill="#031B4E" />

    <!-- Letter R -->
    <path d="M 320 20 L 358 20 C 375 20 386 29 386 43 C 386 54 378 61 366 64 L 388 90 L 375 90 L 354 66 L 330 66 L 330 90 L 320 90 Z M 330 28 L 330 58 L 356 58 C 367 58 375 52 375 43 C 375 34 367 28 356 28 Z" fill="#031B4E" />

    <!-- Letter A: Left leg & crossbar in Navy, Right leg with Imperial Gold Gradient (Brandbook focal point) -->
    <!-- Left leg and apex -->
    <path d="M 444 20 L 452 20 L 434 62 L 448 62 L 452 70 L 430 70 L 422 90 L 410 90 L 438 20 Z" fill="#031B4E" />
    <!-- Right leg with Golden Metallic finish -->
    <path d="M 444 20 L 456 20 L 486 90 L 474 90 L 452 38 L 444 20 Z" fill="url(#evoraGoldGrad)" />
    <!-- Gold crossbar accent -->
    <rect x="432" y="62" width="28" height="7" fill="url(#evoraGoldGrad)" opacity="0.9" />
  </g>

  <!-- Subtitle from Brandbook / Catalog -->
  <text x="270" y="124" font-family="'Inter', sans-serif" font-size="11" letter-spacing="7" fill="#C59827" text-anchor="middle" font-weight="600">PEPTÍDEOS PARA UMA VIDA EXTRAORDINÁRIA</text>
</svg>`;

fs.writeFileSync(path.join(publicDir, 'logo', 'evora-logo.svg'), logoMasterSvg);

// 2. Official EVORA Wordmark (Dark Luxury Master for Dark Navy / Deep Indigo)
const logoDarkLuxurySvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 540 140" fill="none">
  <defs>
    <linearGradient id="evoraGoldGradDark" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#F5E4A8" />
      <stop offset="35%" stop-color="#DFC066" />
      <stop offset="70%" stop-color="#C59827" />
      <stop offset="100%" stop-color="#936F15" />
    </linearGradient>
  </defs>

  <g transform="translate(10, 15)">
    <!-- Letter E -->
    <path d="M 30 20 L 78 20 L 78 28 L 40 28 L 40 50 L 74 50 L 74 58 L 40 58 L 40 82 L 80 82 L 80 90 L 30 90 Z" fill="#FFFFFF" />

    <!-- Letter V -->
    <path d="M 108 20 L 120 20 L 145 76 L 170 20 L 182 20 L 152 90 L 138 90 Z" fill="#FFFFFF" />

    <!-- Letter O -->
    <path d="M 248 18 C 273 18 293 34 293 55 C 293 76 273 92 248 92 C 223 92 203 76 203 55 C 203 34 223 18 248 18 Z M 248 27 C 267 27 282 39 282 55 C 282 71 267 83 248 83 C 229 83 214 71 214 55 C 214 39 229 27 248 27 Z" fill="#FFFFFF" />

    <!-- Letter R -->
    <path d="M 320 20 L 358 20 C 375 20 386 29 386 43 C 386 54 378 61 366 64 L 388 90 L 375 90 L 354 66 L 330 66 L 330 90 L 320 90 Z M 330 28 L 330 58 L 356 58 C 367 58 375 52 375 43 C 375 34 367 28 356 28 Z" fill="#FFFFFF" />

    <!-- Letter A with Golden Focal Leg -->
    <path d="M 444 20 L 452 20 L 434 62 L 448 62 L 452 70 L 430 70 L 422 90 L 410 90 L 438 20 Z" fill="#FFFFFF" />
    <path d="M 444 20 L 456 20 L 486 90 L 474 90 L 452 38 L 444 20 Z" fill="url(#evoraGoldGradDark)" />
    <rect x="432" y="62" width="28" height="7" fill="url(#evoraGoldGradDark)" opacity="0.9" />
  </g>

  <!-- Subtitle -->
  <text x="270" y="124" font-family="'Inter', sans-serif" font-size="11" letter-spacing="7" fill="#DFC066" text-anchor="middle" font-weight="600">PEPTÍDEOS PARA UMA VIDA EXTRAORDINÁRIA</text>
</svg>`;

fs.writeFileSync(path.join(publicDir, 'logo', 'evora-logo-white.svg'), logoDarkLuxurySvg);
console.log('Brandbook logos created successfully');
