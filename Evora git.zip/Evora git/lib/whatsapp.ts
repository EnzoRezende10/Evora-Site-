export interface WhatsAppProductParam {
  name: string;
  dosage?: string;
  price?: number;
  category?: string;
}

export const EVORA_WHATSAPP_NUMBER = "595976508004";

/**
 * Gera o link direto para o WhatsApp de vendas da EVORA com mensagem padronizada de compra.
 */
export function generateWhatsAppLink(
  product?: WhatsAppProductParam,
  customMessage?: string
): string {
  let message = "";

  if (customMessage) {
    message = customMessage;
  } else if (product) {
    const priceText =
      product.price && product.price > 0
        ? `R$ ${product.price.toLocaleString("pt-BR")}`
        : "Sob consulta";

    message = `Olá! Gostaria de adquirir o seguinte composto do catálogo EVORA:

• Produto: ${product.name}
• Dosagem: ${product.dosage || "Consultar"}
• Valor de Catálogo: ${priceText}

Gostaria de confirmar a disponibilidade e receber as orientações para pagamento com as condições especiais:
• PIX (10% de desconto)
• Cartão (Até 3x sem juros)
• USDT (12% de desconto)

Aguardo retorno do consultor para envio seguro com cadeia fria.`;
  } else {
    message =
      "Olá! Gostaria de conversar com um consultor da EVORA para conhecer o catálogo, tirar dúvidas técnicas e consultar condições de pagamento.";
  }

  return `https://wa.me/${EVORA_WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}
